<?php
/**
 * Kayarine Member Dashboard v2 - Redesigned Layout
 * Based on member_dashboard_preview.html template
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Kayarine_Member_Dashboard_V2 {

    public function __construct() {
        // Shortcode for Member Dashboard
        add_shortcode( 'kayarine_member_dashboard_v2', array( $this, 'render_dashboard' ) );
        
        // AJAX Actions
        add_action( 'wp_ajax_kayarine_cancel_booking', array( $this, 'ajax_cancel_booking' ) );
        add_action( 'wp_ajax_kayarine_reschedule_init', array( $this, 'ajax_reschedule_init' ) );
        add_action( 'wp_ajax_kayarine_reschedule_confirm', array( $this, 'ajax_reschedule_confirm' ) );
    }

    /**
     * Render Dashboard - Responsive Layout
     */
    public function render_dashboard() {
        if ( ! is_user_logged_in() ) {
            return '<p style="text-align:center; color:#718096;">請 <a href="' . esc_url( wp_login_url() ) . '">登入</a> 查看會員中心</p>';
        }

        $user_id = get_current_user_id();
        $user = get_user_by( 'id', $user_id );
        
        // Get Stats
        $points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $tier = Kayarine_Membership::get_tier( $user_id );
        $spend = (float) get_user_meta( $user_id, Kayarine_Membership::META_SPEND, true );
        $tier_info = Kayarine_Membership::get_tier_info( $tier );
        
        // Calculate Progress
        $next_target = $tier_info['next'];
        $progress_percent = 0;
        $upgrade_msg = "您已是最高等級會員！";
        
        if ( $next_target > 0 ) {
            $progress_percent = min( 100, ($spend / $next_target) * 100 );
            $remaining = $next_target - $spend;
            $all_tiers = array('bronze', 'silver', 'gold');
            $current_idx = array_search( $tier, $all_tiers );
            $next_tier_slug = isset($all_tiers[$current_idx+1]) ? $all_tiers[$current_idx+1] : 'vip';
            $next_tier_info = Kayarine_Membership::get_tier_info( $next_tier_slug );
            $upgrade_msg = "再消費 <strong>HK$" . number_format($remaining) . "</strong> 即可升級" . $next_tier_info['label'] . "！";
        }

        // Get Upcoming Bookings
        $today = date( 'Y-m-d' );
        $my_orders = wc_get_orders( array(
            'customer_id' => $user_id,
            'status' => array( 'pending', 'on-hold', 'processing', 'completed' ),
            'limit' => 50,
            'orderby' => 'date',
            'order' => 'DESC',
        ) );

        $upcoming_bookings = array();
        $today_ts = strtotime( $today );

        foreach ( $my_orders as $order ) {
            $has_future_booking = false;
            $order_bookings = array();
            
            foreach ( $order->get_items() as $item_id => $item ) {
                $booking_date = $item->get_meta( 'kayarine_booking_date' );
                
                // Debug: Log if date is empty
                if ( ! $booking_date ) {
                    // Try alternative meta key names
                    $booking_date = $item->get_meta( '_kayarine_booking_date' );
                }
                
                if ( $booking_date ) {
                    $booking_ts = strtotime( $booking_date );
                    // Include today's bookings and future bookings
                    if ( $booking_ts >= $today_ts ) {
                        $has_future_booking = true;
                        $order_bookings[] = array(
                            'item_name' => $item->get_name(),
                            'item_qty' => $item->get_quantity(),
                            'booking_date' => $booking_date
                        );
                    }
                }
            }
            
            // If this order has future bookings, add it to the list
            if ( $has_future_booking && ! empty( $order_bookings ) ) {
                $earliest_date = min( array_column( $order_bookings, 'booking_date' ) );
                
                if ( ! isset( $upcoming_bookings[ $order->get_id() ] ) ) {
                    $upcoming_bookings[ $order->get_id() ] = array(
                        'order_id' => $order->get_id(),
                        'date' => $earliest_date,
                        'status' => $order->get_status(),
                        'items' => array(),
                        'can_reschedule' => $this->can_reschedule( $earliest_date, $order ),
                        'can_cancel' => $this->can_cancel( $earliest_date, $order )
                    );
                }
                
                foreach ( $order_bookings as $booking ) {
                    $upcoming_bookings[ $order->get_id() ]['items'][] = $booking['item_name'] . " x" . $booking['item_qty'];
                }
            }
        }
        
        // Sort by date
        uasort( $upcoming_bookings, function( $a, $b ) {
            return strtotime( $a['date'] ) - strtotime( $b['date'] );
        });
        
        // Enqueue assets
        wp_enqueue_style( 'kayarine-booking-css' );
        wp_enqueue_style( 'flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css' );
        wp_enqueue_script( 'flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', array('jquery'), null, true );

        ob_start();
        ?>
        <style>
        /* Member Dashboard v2 - Responsive Grid */
        @media (min-width: 768px) {
            .member-dashboard-grid {
                display: grid !important;
                grid-template-columns: 300px 1fr !important;
                gap: 24px !important;
            }
        }
        
        .dashboard-card {
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
            padding: 24px;
            border: 1px solid #e2e8f0;
        }

        .card-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 20px;
            color: #2d3748;
            border-bottom: 2px solid #7B68EE;
            padding-bottom: 10px;
            display: inline-block;
        }

        .profile-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .user-avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%);
            border-radius: 50%;
            margin: 0 auto 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            color: white;
            box-shadow: 0 4px 12px rgba(255, 140, 66, 0.3);
        }

        .user-name {
            font-size: 1.2rem;
            font-weight: 700;
            color: #2d3748;
        }

        .tier-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 8px;
            background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%);
            color: white;
            border: none;
            box-shadow: 0 2px 8px rgba(255, 140, 66, 0.2);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
            margin-bottom: 20px;
        }

        .stat-box {
            background: #f7fafc;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-label {
            font-size: 0.8rem;
            color: #718096;
            margin-bottom: 4px;
        }

        .stat-value {
            font-size: 1.1rem;
            font-weight: 800;
            color: #2d3748;
        }

        .points-val { color: #FF8C42; }

        .booking-item {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 16px;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            background: #fff;
            gap: 12px;
            flex-wrap: wrap;
            margin-bottom: 12px;
        }

        .booking-info {
            flex: 1;
            min-width: 200px;
        }

        .booking-date {
            font-weight: 700;
            font-size: 1rem;
            color: #2d3748;
        }

        .booking-details {
            font-size: 0.9rem;
            color: #718096;
            margin-top: 4px;
        }

        .booking-status {
            display: inline-block;
            font-size: 0.75rem;
            padding: 2px 8px;
            border-radius: 4px;
            margin-left: 8px;
            background: #C6F6D5;
            color: #22543D;
        }

        .booking-actions {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
        }

        .btn-action {
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }

        .btn-reschedule {
            background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%);
            color: white;
        }

        .btn-cancel {
            background: #FED7D7;
            color: #C53030;
        }

        .btn-action:hover {
            transform: translateY(-1px);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        /* Reschedule Modal */
        .kb-modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .kb-modal-content {
            background: white;
            border-radius: 12px;
            padding: 30px;
            max-width: 400px;
            width: 90%;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
            position: relative;
        }

        .kb-modal-close {
            position: absolute;
            top: 15px;
            right: 15px;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #718096;
        }

        .kb-input-date {
            width: 100% !important;
            padding: 10px 12px !important;
            border: 1px solid #e2e8f0 !important;
            border-radius: 6px !important;
            font-size: 1rem !important;
            margin: 15px 0 !important;
            box-sizing: border-box !important;
        }

        .kb-submit-button {
            width: 100% !important;
            padding: 12px !important;
            background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%) !important;
            color: white !important;
            border: none !important;
            border-radius: 6px !important;
            font-weight: 700 !important;
            cursor: pointer !important;
            margin-top: 15px !important;
            transition: all 0.3s !important;
        }

        .kb-submit-button:hover {
            transform: translateY(-2px) !important;
            box-shadow: 0 4px 12px rgba(255, 140, 66, 0.3) !important;
        }

        #reschedule-msg {
            font-size: 0.9rem;
            padding: 10px;
            border-radius: 4px;
            margin: 10px 0;
        }

        .progress-section {
            margin-top: 20px;
            background: #fff;
            border: 1px solid #e2e8f0;
            padding: 20px;
            border-radius: 12px;
        }

        .progress-label {
            display: flex;
            justify-content: space-between;
            font-size: 0.85rem;
            margin-bottom: 10px;
            color: #718096;
        }

        .progress-bar-bg {
            width: 100%;
            height: 8px;
            background: #edf2f7;
            border-radius: 4px;
            overflow: hidden;
        }

        .progress-bar-fill {
            height: 100%;
            background: linear-gradient(90deg, #FF8C42 0%, #FF7A3D 100%);
            border-radius: 4px;
            transition: width 0.5s ease;
        }

        .upgrade-hint {
            font-size: 0.85rem;
            color: #FF8C42;
            margin-top: 8px;
            text-align: center;
        }
        </style>

        <div class="member-dashboard-grid" style="display:grid; grid-template-columns:1fr; gap:24px;">
            
            <!-- Sidebar -->
            <aside class="dashboard-card">
                <div class="profile-header">
                    <div class="user-avatar">👤</div>
                    <div class="user-name"><?php echo esc_html( $user->display_name ); ?></div>
                    <div class="tier-badge"><?php echo $tier_info['label']; ?> <?php if($tier=='vip') echo '👑'; ?></div>
                </div>

                <div class="stats-grid">
                    <div class="stat-box">
                        <div class="stat-label">現有積分</div>
                        <div class="stat-value points-val"><?php echo number_format($points); ?></div>
                    </div>
                </div>

                <?php if ( $next_target > 0 ): ?>
                <div class="progress-section">
                    <div class="progress-label">
                        <span>目前消費: HK$<?php echo number_format($spend); ?></span>
                        <span>目標: HK$<?php echo number_format($next_target); ?></span>
                    </div>
                    <div class="progress-bar-bg">
                        <div class="progress-bar-fill" style="width: <?php echo $progress_percent; ?>%;"></div>
                    </div>
                    <div class="upgrade-hint"><?php echo $upgrade_msg; ?></div>
                </div>
                <?php endif; ?>

                <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">
                
                <div style="font-size: 0.9rem; color: #4a5568;">
                    <strong>目前權益：</strong>
                    <ul style="padding-left: 20px; margin-top: 8px;">
                        <li>每筆消費享 2% 積分回饋</li>
                        <li>積分可折抵現金</li>
                        <li>早上 9:00 前免費改期</li>
                    </ul>
                </div>
            </aside>

            <!-- Main Content -->
            <main>
                <div class="dashboard-card">
                    <div class="card-title">我的預約 Upcoming Bookings</div>
                    
                    <?php if ( empty( $upcoming_bookings ) ): ?>
                        <p style="text-align:center; color:#a0aec0; font-size:0.9rem;">沒有更多預約了</p>
                    <?php else: ?>
                        <div class="booking-list">
                            <?php foreach ( $upcoming_bookings as $b ): ?>
                                <div class="booking-item">
                                    <div class="booking-info">
                                        <span class="booking-date"><?php echo esc_html( $b['date'] ); ?> (訂單 #<?php echo $b['order_id']; ?>)</span>
                                        <span class="booking-status"><?php echo wc_get_order_status_name($b['status']); ?></span>
                                        <div class="booking-details">
                                            <?php echo esc_html( implode(', ', $b['items']) ); ?>
                                        </div>
                                    </div>
                                    <div class="booking-actions">
                                        <?php if ( $b['can_reschedule'] ): ?>
                                            <button class="btn-action btn-reschedule" data-id="<?php echo $b['order_id']; ?>" data-date="<?php echo esc_attr($b['date']); ?>">改期</button>
                                        <?php endif; ?>
                                        
                                        <?php if ( $b['can_cancel'] ): ?>
                                            <button class="btn-action btn-cancel" data-id="<?php echo $b['order_id']; ?>">取消</button>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>

        <!-- Reschedule Modal -->
        <div id="kb-reschedule-modal" class="kb-modal-overlay">
            <div class="kb-modal-content">
                <button type="button" class="kb-modal-close" onclick="document.getElementById('kb-reschedule-modal').style.display='none';">&times;</button>
                <h3 style="margin-top:0;">選擇新的預約日期</h3>
                <p style="color:#718096;">訂單 #<span id="modal-order-id"></span></p>
                <input type="text" id="new_date_picker" class="kb-input-date" placeholder="選擇新日期">
                <div id="reschedule-msg"></div>
                <button id="confirm-reschedule-btn" class="kb-submit-button">確認更改</button>
            </div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            var currentOrderId = 0;
            var fp = null;

            // Cancel Booking
            $('.btn-cancel').click(function() {
                if(!confirm('確定要取消此預約嗎？款項將退回至您的帳戶。')) return;
                
                var order_id = $(this).data('id');
                var btn = $(this);
                btn.prop('disabled', true).text('處理中...');

                $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                    action: 'kayarine_cancel_booking',
                    order_id: order_id
                }, function(res) {
                    if(res.success) {
                        alert(res.data.message);
                        location.reload();
                    } else {
                        alert(res.data.message || '取消失敗');
                        btn.prop('disabled', false).text('取消');
                    }
                });
            });

            // Reschedule Modal
            $('.btn-reschedule').click(function() {
                currentOrderId = $(this).data('id');
                $('#modal-order-id').text(currentOrderId);
                $('#kb-reschedule-modal').css('display', 'flex');
                
                if(fp) fp.destroy();
                fp = flatpickr("#new_date_picker", {
                    minDate: "today",
                    disable: <?php echo json_encode(Kayarine_Inventory::get_blackout_dates()); ?>,
                    dateFormat: "Y-m-d",
                });
            });

            // Confirm Reschedule
            $('#confirm-reschedule-btn').click(function() {
                var newDate = $('#new_date_picker').val();
                var msgDiv = $('#reschedule-msg');
                
                if(!newDate) {
                    msgDiv.show().css('background', '#fee').css('color', '#c00').css('borderLeft', '4px solid #c00').text('請選擇日期');
                    return;
                }

                $(this).prop('disabled', true).text('處理中...');
                
                $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                    action: 'kayarine_reschedule_confirm',
                    order_id: currentOrderId,
                    new_date: newDate
                }, function(res) {
                    if(res.success) {
                        msgDiv.show().css('background', '#efe').css('color', '#050').css('borderLeft', '4px solid #0a0').text('改期成功！');
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        msgDiv.show().css('background', '#fee').css('color', '#c00').css('borderLeft', '4px solid #c00').text(res.data.message || '改期失敗');
                        $('#confirm-reschedule-btn').prop('disabled', false).text('確認更改');
                    }
                });
            });
        });
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Can Cancel Check
     */
    private function can_cancel( $booking_date, $order ) {
        return $this->check_time_rule( $booking_date );
    }

    /**
     * Can Reschedule Check
     */
    private function can_reschedule( $booking_date, $order ) {
        if ( $order->get_status() == 'pending' ) {
            return true;
        }
        return $this->check_time_rule( $booking_date );
    }

    /**
     * Check Time Rule (Before 9:00 AM on booking date)
     */
    private function check_time_rule( $booking_date ) {
        $now = current_time( 'timestamp' );
        $deadline = strtotime( $booking_date . ' 09:00:00' );
        return ( $now < $deadline );
    }

    /**
     * AJAX: Cancel Booking
     */
    public function ajax_cancel_booking() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array('message'=>'請先登入') );
        
        $order_id = intval( $_POST['order_id'] );
        $order = wc_get_order( $order_id );
        
        if ( ! $order || $order->get_user_id() != get_current_user_id() ) {
            wp_send_json_error( array('message'=>'訂單無效') );
        }

        $items = $order->get_items();
        $booking_date = '';
        foreach($items as $item) {
            $booking_date = $item->get_meta('kayarine_booking_date');
            break;
        }

        if ( ! $this->check_time_rule( $booking_date ) ) {
            wp_send_json_error( array('message'=>'已超過取消時限 (當日 9:00 AM 前)') );
        }

        $membership = new Kayarine_Membership();
        
        foreach ( $order->get_fees() as $fee ) {
            if ( $fee->get_name() == '會員積分折抵' ) {
                $points_back = abs( $fee->get_total() );
                $membership->adjust_points( $order->get_user_id(), $points_back, 'refund', $order_id, "訂單 #{$order_id} 取消退還積分" );
            }
        }

        $earned = $order->get_meta( '_kayarine_points_awarded' );
        if ( $earned ) {
            $membership->adjust_points( $order->get_user_id(), -$earned, 'adjust', $order_id, "訂單 #{$order_id} 取消扣回贈分" );
        }

        $order->update_status( 'cancelled', 'User cancelled via dashboard.' );
        
        wp_send_json_success( array('message'=>'取消成功，積分已退回至您的帳戶。') );
    }

    /**
     * AJAX: Confirm Reschedule
     */
    public function ajax_reschedule_confirm() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array('message'=>'請先登入') );
        
        $order_id = intval( $_POST['order_id'] );
        $new_date = sanitize_text_field( $_POST['new_date'] );
        
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_user_id() != get_current_user_id() ) {
            wp_send_json_error( array('message'=>'訂單無效') );
        }

        if ( Kayarine_Inventory::is_blackout( $new_date ) ) {
            wp_send_json_error( array('message'=>'所選日期無法預約') );
        }

        $limits = Kayarine_Inventory::get_limits();
        $usage = Kayarine_Inventory::get_daily_usage( $new_date );
        
        foreach ( $order->get_items() as $item ) {
            $pid = $item->get_product_id();
            $qty = $item->get_quantity();
            
            if ( isset($limits[$pid]) ) {
                $used = isset($usage[$pid]) ? $usage[$pid] : 0;
                if ( $used + $qty > $limits[$pid] ) {
                    wp_send_json_error( array('message'=>$item->get_name() . " 在該日期庫存不足") );
                }
            }
        }

        foreach ( $order->get_items() as $item ) {
            $item->update_meta_data( 'kayarine_booking_date', $new_date );
            $item->save();
        }
        
        if ( $order->get_status() == 'pending' ) {
            $order->update_status( 'processing', 'Rescheduled by user from Pending.' );
        } else {
            $order->add_order_note( "User rescheduled to $new_date" );
        }
        $order->save();

        wp_send_json_success( array('message'=>'改期成功') );
    }
}

// Initialize
new Kayarine_Member_Dashboard_V2();
