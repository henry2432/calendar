<?php
/**
 * Kayarine Checkout Manager
 * Handles Points Redemption and Wallet Usage at Checkout.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Kayarine_Checkout_Manager {

    public function __construct() {
        // Display Points UI in Checkout (Wallet removed)
        add_action( 'woocommerce_review_order_before_payment', array( $this, 'render_loyalty_options' ) );
        
        // Process AJAX actions for points redemption only
        add_action( 'wp_ajax_kayarine_apply_points', array( $this, 'ajax_apply_points' ) );
        add_action( 'wp_ajax_nopriv_kayarine_apply_points', array( $this, 'ajax_apply_points' ) );

        // Calculate Totals (Discount)
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_discounts' ) );
        
        // Deduct points on successful payment
        add_action( 'woocommerce_order_status_processing', array( $this, 'deduct_loyalty_balance' ) );
        add_action( 'woocommerce_order_status_completed', array( $this, 'deduct_loyalty_balance' ) );
    }

    /**
     * Render UI above Payment Methods
     */
    public function render_loyalty_options() {
        if ( ! is_user_logged_in() ) {
            echo '<div class="woocommerce-info">登入後可使用會員積分。 <a href="' . get_permalink( get_option('woocommerce_myaccount_page_id') ) . '">按此登入</a></div>';
            return;
        }

        $user_id = get_current_user_id();
        $points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $tier = Kayarine_Membership::get_tier( $user_id );
        
        // Get applied sessions
        $applied_points = WC()->session->get( 'kayarine_points_applied', 0 );
        
        // Calculate max usable (Cart Total)
        $cart_total = WC()->cart->get_subtotal() + WC()->cart->get_shipping_total(); 
        // Note: get_total() includes fees, so circular dependency if not careful. Use subtotal.
        
        ?>
        <div id="kayarine-loyalty-checkout" class="kayarine-booking-card" style="padding: 15px; margin-bottom: 20px; border-color: #ed8936;">
            <h4 style="margin-top:0;">會員優惠 (<?php echo Kayarine_Membership::get_tier_info($tier)['label']; ?>)</h4>
            
            <!-- Points Section Only -->
            <div class="kb-checkout-section" style="margin-bottom: 15px;">
                <label>
                    <input type="checkbox" id="use_points_check" <?php checked( $applied_points > 0 ); ?>>
                    使用積分折抵 (現有: <?php echo $points; ?> 分)
                </label>
                <div id="points_input_wrap" style="display: <?php echo $applied_points > 0 ? 'block' : 'none'; ?>; margin-top: 5px; padding-left: 20px;">
                    <input type="number" id="points_amount" value="<?php echo $applied_points ? $applied_points : ''; ?>" placeholder="輸入積分 (1分 = $1)" max="<?php echo $points; ?>" style="width: 150px;">
                    <button type="button" class="button" id="apply_points_btn">套用</button>
                    <p class="description" style="font-size: 12px;">每 1 積分可折抵 HK$1。</p>
                </div>
            </div>
            
            <div id="loyalty_message"></div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // Toggle Visibility - Points Only
            $('#use_points_check').change(function() {
                $('#points_input_wrap').toggle(this.checked);
                if(!this.checked) trigger_ajax('points', 0);
            });

            // Apply Button - Points Only
            $('#apply_points_btn').click(function() {
                var amt = $('#points_amount').val();
                trigger_ajax('points', amt);
            });

            function trigger_ajax(type, amount) {
                $('#loyalty_message').text('處理中...').css('color', '#666');
                $('body').trigger('update_checkout'); // Lock checkout

                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'kayarine_apply_' + type,
                        amount: amount
                    },
                    success: function(response) {
                        if(response.success) {
                            $('#loyalty_message').text(response.data.message).css('color', 'green');
                            $('body').trigger('update_checkout'); // Refresh totals
                        } else {
                            $('#loyalty_message').text(response.data.message).css('color', 'red');
                        }
                    }
                });
            }
        });
        </script>
        <?php
    }

    /**
     * AJAX: Apply Points
     */
    public function ajax_apply_points() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array( 'message' => '請先登入' ) );
        
        $user_id = get_current_user_id();
        $amount = intval( $_POST['amount'] );
        $max_points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );

        if ( $amount < 0 ) $amount = 0;
        if ( $amount > $max_points ) {
            wp_send_json_error( array( 'message' => '積分不足' ) );
        }

        // Limit to Cart Total? Handled in apply_discounts logically, 
        // but user might input more than total. We accept it here and clamp later or let fees handle it (negative total impossible in WC usually).
        
        WC()->session->set( 'kayarine_points_applied', $amount );
        wp_send_json_success( array( 'message' => $amount > 0 ? "已套用 {$amount} 積分" : "已取消積分使用" ) );
    }

    /**
     * Calculate Fees (Negative Fees = Discount) - Points Only
     */
    public function apply_discounts( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
        if ( ! is_user_logged_in() ) return;

        $points = WC()->session->get( 'kayarine_points_applied', 0 );
        
        // Safety Check against user balance again
        $user_id = get_current_user_id();
        $max_points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );

        if ( $points > $max_points ) $points = $max_points;

        // Calculate Cart Total to prevent negative
        $cart_total = $cart->subtotal + $cart->shipping_total; // Before fees
        
        if ( $points > 0 ) {
            // 1 Point = $1 Discount
            $discount = min( $points, $cart_total );
            $cart->add_fee( '會員積分折抵', -$discount );
        }
    }

    /**
     * Deduct Balance on Order Payment - Points Only
     */
    public function deduct_loyalty_balance( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;
        
        // Check if already deducted
        if ( $order->get_meta( '_kayarine_loyalty_deducted' ) ) return;

        $user_id = $order->get_user_id();
        
        // Parse Fees to find points deductions
        $points_used = 0;

        foreach ( $order->get_fees() as $fee ) {
            if ( $fee->get_name() == '會員積分折抵' ) {
                $points_used += abs( $fee->get_total() ); // Fee is negative
            }
        }

        $membership = new Kayarine_Membership();

        if ( $points_used > 0 ) {
            $membership->adjust_points( $user_id, -$points_used, 'redeem', $order_id, "訂單 #{$order_id} 折抵" );
            $order->update_meta_data( '_kayarine_loyalty_deducted', 1 );
            $order->save();
        }
        
        // Clear session
        if ( isset( WC()->session ) ) {
            WC()->session->set( 'kayarine_points_applied', 0 );
        }
    }
}
