<?php
/**
 * Kayarine Member Dashboard
 * Handles Frontend Member Area, Booking Management, Rescheduling, and Cancellation.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Kayarine_Member_Dashboard {

    public function __construct() {
        // Shortcode for My Account Page integration
        add_shortcode( 'kayarine_member_dashboard', array( $this, 'render_dashboard' ) );
        
        // Add to WooCommerce My Account Menu (Optional, or just put shortcode in a page)
        add_action( 'init', array( $this, 'add_endpoint' ) );
        add_filter( 'query_vars', array( $this, 'add_query_vars' ), 0 );
        add_filter( 'woocommerce_account_menu_items', array( $this, 'add_link_my_account' ) );
        add_action( 'woocommerce_account_kayarine-member_endpoint', array( $this, 'render_dashboard' ) );

        // AJAX Actions
        add_action( 'wp_ajax_kayarine_cancel_booking', array( $this, 'ajax_cancel_booking' ) );
        add_action( 'wp_ajax_kayarine_reschedule_init', array( $this, 'ajax_reschedule_init' ) ); // Get available dates
        add_action( 'wp_ajax_kayarine_reschedule_confirm', array( $this, 'ajax_reschedule_confirm' ) ); // Do it
    }

    /**
     * Add 'Member Center' endpoint to WC My Account
     */
    public function add_endpoint() {
        add_rewrite_endpoint( 'kayarine-member', EP_ROOT | EP_PAGES );
    }

    public function add_query_vars( $vars ) {
        $vars[] = 'kayarine-member';
        return $vars;
    }

    public function add_link_my_account( $items ) {
        // Insert after 'dashboard'
        $new_items = array();
        foreach ( $items as $key => $val ) {
            $new_items[$key] = $val;
            if ( $key == 'dashboard' ) {
                $new_items['kayarine-member'] = '會員中心 (Member Center)';
            }
        }
        return $new_items;
    }

    /**
     * Render Dashboard HTML
     * This handles the display of the [kayarine_member_dashboard] shortcode.
     */
    public function render_dashboard() {
        // If user is not logged in, display custom tab system with WordPress shortcodes
        if ( ! is_user_logged_in() ) {
            // Enqueue Styles & Scripts
            wp_enqueue_style( 'kayarine-booking-css' );
            wp_enqueue_script( 'jquery' );
            ?>
            <div class="kayarine-auth-wrapper">
                <div class="kayarine-auth-container">
                    <!-- Header -->
                    <div class="kayarine-auth-header">
                        <h1>Kayarine 會員中心</h1>
                        <p>登入或註冊以管理您的預約</p>
                    </div>

                    <!-- Tab Navigation -->
                    <div class="kayarine-auth-tabs">
                        <button class="kayarine-auth-tab-btn active" data-tab="login">
                            🔐 會員登入
                        </button>
                        <button class="kayarine-auth-tab-btn" data-tab="register">
                            ✨ 免費註冊
                        </button>
                    </div>

                    <!-- Login Tab -->
                    <div id="kayarine-login-tab" class="kayarine-auth-panel active">
                        <div class="kayarine-auth-panel-content">
                            <?php echo do_shortcode( '[woocommerce_my_account]' ); ?>
                        </div>
                    </div>

                    <!-- Register Tab -->
                    <div id="kayarine-register-tab" class="kayarine-auth-panel">
                        <div class="kayarine-auth-panel-content">
                            <?php
                            // Try user_registration shortcode first, fallback to WooCommerce registration
                            if ( shortcode_exists( 'user_registration_form' ) ) {
                                echo do_shortcode( '[user_registration_form id="1"]' );
                            } else {
                                // Fallback: WooCommerce registration on my-account page
                                echo '<p>請 <a href="' . esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ) . '">點擊這裡註冊</a></p>';
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>

            <script>
            jQuery(document).ready(function($) {
                // Tab Switching
                $('.kayarine-auth-tab-btn').on('click', function() {
                    var tabName = $(this).data('tab');
                    
                    // Remove active from all
                    $('.kayarine-auth-tab-btn').removeClass('active');
                    $('.kayarine-auth-panel').removeClass('active');
                    
                    // Add active to selected
                    $(this).addClass('active');
                    $('#kayarine-' + tabName + '-tab').addClass('active');
                });
            });
            </script>
            <?php
            return;
        }

        $user_id = get_current_user_id();
        
        // Get Stats
        $points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $tier = Kayarine_Membership::get_tier( $user_id );
        $spend = (float) get_user_meta( $user_id, Kayarine_Membership::META_SPEND, true );
        $tier_info = Kayarine_Membership::get_tier_info( $tier );
        
        // Calculate Progress
        $next_target = $tier_info['next'];
        $progress_percent = 0;
        $upgrade_msg = "您已是最高等級會員！";
        
        if ( $next_target > 0 ) {
            $progress_percent = min( 100, ($spend / $next_target) * 100 );
            $remaining = $next_target - $spend;
            // Find next tier label
            $all_tiers = array('bronze', 'silver', 'gold');
            $current_idx = array_search( $tier, $all_tiers );
            $next_tier_slug = isset($all_tiers[$current_idx+1]) ? $all_tiers[$current_idx+1] : 'vip';
            $next_tier_info = Kayarine_Membership::get_tier_info( $next_tier_slug );
            $upgrade_msg = "再消費 <strong>HK$" . number_format($remaining) . "</strong> 即可升級{$next_tier_info['label']}！";
        } elseif ( $tier == 'vip' ) {
            $upgrade_msg = "尊貴會員享永久平日價優惠。";
        }

        // Get Upcoming Bookings
        // Logic: Find Orders with status 'processing' or 'completed' and custom date meta >= Today
        // This is tricky with standard WC queries. Better to query order items or use meta query on orders if we store date in order meta.
        // We store 'kayarine_booking_date' in item meta.
        // Let's query orders first, then filter.
        
        $today = date( 'Y-m-d' );
        $my_orders = wc_get_orders( array(
            'customer_id' => $user_id,
            'status' => array( 'processing', 'completed', 'pending' ), // Pending allowed for "Pending Payment" reschedule case
            'limit' => 10,
            'orderby' => 'date',
            'order' => 'DESC',
        ) );

        $upcoming_bookings = array();

        foreach ( $my_orders as $order ) {
            foreach ( $order->get_items() as $item_id => $item ) {
                $booking_date = $item->get_meta( 'kayarine_booking_date' );
                if ( $booking_date && $booking_date >= $today ) {
                    // Group by Order or show individual items? Group by Order usually better for cancellation.
                    if ( ! isset( $upcoming_bookings[ $order->get_id() ] ) ) {
                        $upcoming_bookings[ $order->get_id() ] = array(
                            'order_id' => $order->get_id(),
                            'date' => $booking_date,
                            'status' => $order->get_status(),
                            'items' => array(),
                            'can_reschedule' => $this->can_reschedule( $booking_date, $order ),
                            'can_cancel' => $this->can_cancel( $booking_date, $order )
                        );
                    }
                    $upcoming_bookings[ $order->get_id() ]['items'][] = $item->get_name() . " x" . $item->get_quantity();
                }
            }
        }
        
        // Enqueue Styles/Scripts
        wp_enqueue_style( 'kayarine-booking-css' ); 
        // Need flatpickr for reschedule modal
        wp_enqueue_style( 'flatpickr-css', 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css' );
        wp_enqueue_script( 'flatpickr-js', 'https://cdn.jsdelivr.net/npm/flatpickr', array('jquery'), null, true );

        ?>
        <div class="member-dashboard kayarine-booking-card" style="border:none; box-shadow:none; padding:0; max-width:none;">
            
            <!-- Header Stats -->
            <div class="stats-grid" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap:20px; margin-bottom:30px;">
                <div class="stat-box" style="background:#f7fafc; padding:20px; border-radius:12px; text-align:center;">
                    <div class="stat-label">等級 Tier</div>
                    <div class="stat-value" style="font-size:1.2rem; font-weight:bold; color:#2c5282;">
                        <?php echo $tier_info['label']; ?>
                        <?php if($tier=='vip') echo '👑'; ?>
                    </div>
                </div>
                <div class="stat-box" style="background:#f7fafc; padding:20px; border-radius:12px; text-align:center;">
                    <div class="stat-label">現有積分 Points</div>
                    <div class="stat-value points-val" style="font-size:1.5rem; font-weight:bold; color:#ed8936;"><?php echo number_format($points); ?></div>
                </div>
            </div>

            <!-- Progress -->
            <?php if ( $next_target > 0 ): ?>
            <div class="progress-section" style="margin-bottom:30px; background:#fff; border:1px solid #e2e8f0; padding:20px; border-radius:12px;">
                <div class="progress-label" style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span>目前累積消費: $<?php echo number_format($spend); ?></span>
                    <span>目標: $<?php echo number_format($next_target); ?></span>
                </div>
                <div class="progress-bar-bg" style="background:#edf2f7; height:10px; border-radius:5px; overflow:hidden;">
                    <div class="progress-bar-fill" style="width: <?php echo $progress_percent; ?>%; background:#3182ce; height:100%;"></div>
                </div>
                <p style="text-align:center; margin-top:10px; color:#3182ce; font-size:0.9rem;"><?php echo $upgrade_msg; ?></p>
            </div>
            <?php endif; ?>

            <!-- Bookings -->
            <h3 class="kb-section-title">我的預約 Upcoming Bookings</h3>
            
            <?php if ( empty( $upcoming_bookings ) ): ?>
                <p>目前沒有即將到來的預約。</p>
            <?php else: ?>
                <div class="booking-list">
                    <?php foreach ( $upcoming_bookings as $b ): ?>
                        <div class="booking-item" style="border:1px solid #e2e8f0; padding:20px; margin-bottom:15px; border-radius:12px; background:#fff; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:15px;">
                            <div class="booking-info">
                                <div style="font-weight:bold; font-size:1.1rem; color:#2d3748;">
                                    <?php echo $b['date']; ?> (訂單 #<?php echo $b['order_id']; ?>)
                                    <span style="font-size:0.8rem; background:#C6F6D5; color:#22543D; padding:2px 8px; border-radius:4px; margin-left:10px;">
                                        <?php echo wc_get_order_status_name($b['status']); ?>
                                    </span>
                                </div>
                                <div style="color:#718096; font-size:0.9rem; margin-top:5px;">
                                    <?php echo implode(', ', $b['items']); ?>
                                </div>
                            </div>
                            <div class="booking-actions">
                                <?php if ( $b['can_reschedule'] ): ?>
                                    <button class="button kb-btn-reschedule" data-id="<?php echo $b['order_id']; ?>" data-date="<?php echo $b['date']; ?>">改期</button>
                                <?php endif; ?>
                                
                                <?php if ( $b['can_cancel'] ): ?>
                                    <button class="button kb-btn-cancel" data-id="<?php echo $b['order_id']; ?>" style="background:#FED7D7; color:#C53030; border-color:#FEB2B2;">取消</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Reschedule Modal -->
            <div id="kb-reschedule-modal" class="kb-modal-overlay" style="display:none;">
                <div class="kb-modal-content" style="text-align:center;">
                    <button type="button" class="kb-modal-close" onclick="document.getElementById('kb-reschedule-modal').style.display='none'">&times;</button>
                    <h3>更改預約日期</h3>
                    <p>訂單 #<span id="modal-order-id"></span></p>
                    <input type="text" id="new_date_picker" class="kb-input-date" placeholder="選擇新日期">
                    <div id="reschedule-msg" style="margin:10px 0; color:red;"></div>
                    <button id="confirm-reschedule-btn" class="kb-submit-button">確認更改</button>
                </div>
            </div>

        </div>

        <script>
        jQuery(document).ready(function($) {
            // Cancel
            $('.kb-btn-cancel').click(function() {
                if(!confirm('確定要取消此預約嗎？款項將退回至您的積分帳戶。')) return;
                
                var order_id = $(this).data('id');
                var btn = $(this);
                btn.prop('disabled', true).text('處理中...');

                $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                    action: 'kayarine_cancel_booking',
                    order_id: order_id
                }, function(res) {
                    if(res.success) {
                        alert(res.data.message);
                        location.reload();
                    } else {
                        alert(res.data.message);
                        btn.prop('disabled', false).text('取消');
                    }
                });
            });

            // Reschedule UI
            var currentOrderId = 0;
            var fp = null;

            $('.kb-btn-reschedule').click(function() {
                currentOrderId = $(this).data('id');
                var currentDate = $(this).data('date');
                $('#modal-order-id').text(currentOrderId);
                $('#kb-reschedule-modal').css('display', 'flex');
                
                // Init Flatpickr
                if(fp) fp.destroy();
                fp = flatpickr("#new_date_picker", {
                    minDate: "today",
                    disable: <?php echo json_encode(Kayarine_Inventory::get_blackout_dates()); ?>,
                    dateFormat: "Y-m-d",
                });
            });

            $('#confirm-reschedule-btn').click(function() {
                var newDate = $('#new_date_picker').val();
                if(!newDate) {
                    $('#reschedule-msg').text('請選擇日期');
                    return;
                }

                $(this).prop('disabled', true).text('處理中...');
                
                $.post('<?php echo admin_url('admin-ajax.php'); ?>', {
                    action: 'kayarine_reschedule_confirm',
                    order_id: currentOrderId,
                    new_date: newDate
                }, function(res) {
                    if(res.success) {
                        alert('改期成功！');
                        location.reload();
                    } else {
                        $('#reschedule-msg').text(res.data.message);
                        $('#confirm-reschedule-btn').prop('disabled', false).text('確認更改');
                    }
                });
            });
        });
        </script>
        <?php
    }

    /**
     * Logic: Can Cancel?
     * Rule: Before 9:00 AM on booking date.
     */
    private function can_cancel( $booking_date, $order ) {
        if ( $order->get_status() == 'completed' ) return false; // Already done? Or just paid? Usually 'processing' is paid.
        // Actually, for rentals, 'completed' might mean "Event Passed".
        // Let's assume 'processing' = Paid & Upcoming.
        
        return $this->check_time_rule( $booking_date );
    }

    private function can_reschedule( $booking_date, $order ) {
        // Special Admin Override: If status is 'pending' (Pending Payment used as "Allow Reschedule" flag per prompt)
        // "如顧客因事未能即時決定下次日期,admin可以將訂單設定為pending payment...無論是已過的預訂日期都可以更改"
        if ( $order->get_status() == 'pending' ) {
            return true;
        }

        return $this->check_time_rule( $booking_date );
    }

    private function check_time_rule( $booking_date ) {
        $now = current_time( 'timestamp' ); // WP Local Time
        $booking_ts = strtotime( $booking_date );
        
        // Deadline: Booking Date at 9:00 AM
        $deadline = strtotime( $booking_date . ' 09:00:00' );
        
        if ( $now < $deadline ) {
            return true;
        }
        return false;
    }

    /**
     * AJAX: Cancel Booking - Points Only
     */
    public function ajax_cancel_booking() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array('message'=>'請先登入') );
        
        $order_id = intval( $_POST['order_id'] );
        $order = wc_get_order( $order_id );
        
        if ( ! $order || $order->get_user_id() != get_current_user_id() ) {
            wp_send_json_error( array('message'=>'訂單無效') );
        }

        // Validate Date again
        $items = $order->get_items();
        $booking_date = '';
        foreach($items as $item) {
            $booking_date = $item->get_meta('kayarine_booking_date');
            break;
        }

        if ( ! $this->check_time_rule( $booking_date ) ) {
            wp_send_json_error( array('message'=>'已超過取消時限 (當日 9:00 AM 前)') );
        }

        // Refund to Points Only
        $membership = new Kayarine_Membership();
        
        // Refund Points Used (if any)
        foreach ( $order->get_fees() as $fee ) {
            if ( $fee->get_name() == '會員積分折抵' ) {
                $points_back = abs( $fee->get_total() );
                $membership->adjust_points( $order->get_user_id(), $points_back, 'refund', $order_id, "訂單 #{$order_id} 取消退還積分" );
            }
        }

        // Deduct Earned Points (Clawback)
        $earned = $order->get_meta( '_kayarine_points_awarded' );
        if ( $earned ) {
            $membership->adjust_points( $order->get_user_id(), -$earned, 'adjust', $order_id, "訂單 #{$order_id} 取消扣回贈分" );
        }

        // Cancel Order
        $order->update_status( 'cancelled', 'User cancelled via dashboard.' );
        
        wp_send_json_success( array('message'=>'取消成功，積分已退回至您的帳戶。') );
    }

    /**
     * AJAX: Confirm Reschedule
     */
    public function ajax_reschedule_confirm() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array('message'=>'請先登入') );
        
        $order_id = intval( $_POST['order_id'] );
        $new_date = sanitize_text_field( $_POST['new_date'] );
        
        $order = wc_get_order( $order_id );
        if ( ! $order || $order->get_user_id() != get_current_user_id() ) {
            wp_send_json_error( array('message'=>'訂單無效') );
        }

        // Validate Blackout on New Date
        if ( Kayarine_Inventory::is_blackout( $new_date ) ) {
            wp_send_json_error( array('message'=>'所選日期無法預約') );
        }

        // Validate Availability (Complex: Need to check stock)
        // For simplicity, we assume if not blackout, it's ok? 
        // Ideally we check Kayarine_Inventory::get_availability( $new_date ).
        // Let's do a quick check.
        $limits = Kayarine_Inventory::get_limits();
        $usage = Kayarine_Inventory::get_daily_usage( $new_date );
        
        // What items are in this order?
        foreach ( $order->get_items() as $item ) {
            $pid = $item->get_product_id();
            $qty = $item->get_quantity();
            
            if ( isset($limits[$pid]) ) {
                $used = isset($usage[$pid]) ? $usage[$pid] : 0;
                if ( $used + $qty > $limits[$pid] ) {
                    wp_send_json_error( array('message'=>"{$item->get_name()} 在該日期庫存不足") );
                }
            }
        }

        // Update Date
        foreach ( $order->get_items() as $item ) {
            $item->update_meta_data( 'kayarine_booking_date', $new_date );
            $item->save();
        }
        
        // If it was 'pending' (admin unlock), move back to 'processing' or 'completed'
        if ( $order->get_status() == 'pending' ) {
            $order->update_status( 'processing', 'Rescheduled by user from Pending.' );
        } else {
            $order->add_order_note( "User rescheduled to $new_date" );
        }
        $order->save();

        wp_send_json_success( array('message'=>'改期成功') );
    }
}
