<?php
/**
 * Kayarine WooCommerce Customizer - Minimal Test Version
 * Testing if shortcode registration works
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Kayarine_WooCommerce_Customizer {

    public function __construct() {
        // 只註冊 shortcode，測試是否能工作
        add_shortcode( 'kayarine_account', array( $this, 'render_kayarine_account_shortcode' ) );
        
        // 註冊自定義端點
        add_action( 'init', array( $this, 'add_custom_endpoint' ) );
        
        // 自定義帳戶菜單
        add_filter( 'woocommerce_account_menu_items', array( $this, 'customize_account_menu' ), 10, 1 );
        
        // 渲染自定義端點
        add_action( 'woocommerce_account_kayarine-membership_endpoint', array( $this, 'render_membership_dashboard' ) );
        
        // AJAX 處理
        add_action( 'wp_ajax_nopriv_kayarine_custom_login', array( $this, 'handle_custom_login' ) );
        add_action( 'wp_ajax_nopriv_kayarine_custom_register', array( $this, 'handle_custom_register' ) );
        
        // 樣式和腳本
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_custom_styles' ) );
        
        // 查詢變數
        add_filter( 'query_vars', array( $this, 'add_custom_query_vars' ) );
    }

    public function add_custom_endpoint() {
        add_rewrite_endpoint( 'kayarine-membership', EP_ROOT | EP_PAGES );
    }

    public function add_custom_query_vars( $vars ) {
        $vars[] = 'kayarine-membership';
        return $vars;
    }

    /**
     * Main shortcode
     */
    public function render_kayarine_account_shortcode() {
        if ( is_user_logged_in() ) {
            return $this->render_logged_in_account();
        } else {
            return $this->render_login_register_ui();
        }
    }

    /**
     * Render login/register UI
     */
    private function render_login_register_ui() {
        ob_start();
        ?>
        <div class="kayarine-auth-wrapper-orange">
            <div class="kayarine-auth-container-orange">
                <div class="kayarine-auth-header-orange">
                    <h1>Kayarine 會員中心</h1>
                    <p>登入或註冊以管理您的預約</p>
                </div>

                <div class="kayarine-auth-tabs-orange">
                    <button class="kayarine-auth-tab-btn-orange active" data-tab="login" type="button">
                        🔐 會員登入
                    </button>
                    <button class="kayarine-auth-tab-btn-orange" data-tab="register" type="button">
                        ✨ 免費註冊
                    </button>
                </div>

                <div id="kayarine-login-tab" class="kayarine-auth-panel-orange active">
                    <div class="kayarine-auth-panel-content-orange">
                        <?php $this->render_login_form(); ?>
                    </div>
                </div>

                <div id="kayarine-register-tab" class="kayarine-auth-panel-orange">
                    <div class="kayarine-auth-panel-content-orange">
                        <?php $this->render_register_form(); ?>
                    </div>
                </div>
            </div>
        </div>

        <style>
        <?php echo $this->get_custom_css(); ?>
        </style>

        <script>
        <?php echo $this->get_ajax_handler_js(); ?>
        </script>
        <?php
        return ob_get_clean();
    }

    private function render_logged_in_account() {
        ob_start();
        ?>
        <div class="kayarine-logged-in-account">
            <?php
            if ( function_exists( 'woocommerce_account_navigation' ) ) {
                woocommerce_account_navigation();
            }
            
            $kayarine_membership = get_query_var( 'kayarine-membership' );
            if ( ! empty( $kayarine_membership ) ) {
                $this->render_membership_dashboard();
            } else {
                if ( function_exists( 'woocommerce_account_content' ) ) {
                    woocommerce_account_content();
                }
            }
            ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function render_login_form() {
        $redirect_url = home_url( '/account/' );
        ?>
        <h2>登入您的帳戶</h2>
        <p class="kayarine-auth-subtitle">登入以管理您的預約、查看優惠和管理會員檔案。</p>

        <form id="kayarine-login-form" class="kayarine-login-form">
            <input type="hidden" name="action" value="kayarine_custom_login">
            <input type="hidden" name="redirect_to" value="<?php echo esc_attr( $redirect_url ); ?>">
            <?php wp_nonce_field( 'kayarine_login_nonce', 'kayarine_login_nonce_field', false ); ?>
            
            <div class="kayarine-form-group">
                <label for="kayarine_user_login">電子郵件或用戶名</label>
                <input 
                    type="text" 
                    name="log" 
                    id="kayarine_user_login" 
                    class="kayarine-form-input"
                    placeholder="請輸入電子郵件或用戶名"
                    required
                >
            </div>

            <div class="kayarine-form-group">
                <label for="kayarine_user_pass">密碼</label>
                <input 
                    type="password" 
                    name="pwd" 
                    id="kayarine_user_pass" 
                    class="kayarine-form-input"
                    placeholder="請輸入密碼"
                    required
                >
            </div>

            <div class="kayarine-form-group kayarine-checkbox-group">
                <label for="kayarine_rememberme">
                    <input type="checkbox" name="rememberme" id="kayarine_rememberme" value="forever">
                    記住我
                </label>
            </div>

            <button type="submit" class="kayarine-btn-submit">登入</button>
            <div id="kayarine-login-message" class="kayarine-form-message"></div>
        </form>

        <div class="kayarine-auth-footer">
            <p><a href="<?php echo esc_url( wp_lostpassword_url() ); ?>">忘記密碼？</a></p>
        </div>
        <?php
    }

    private function render_register_form() {
        ?>
        <h2>建立帳戶</h2>
        <p class="kayarine-auth-subtitle">加入 Kayarine 會員社群，享受獨家優惠及積分獎勵</p>

        <div class="kayarine-benefits-grid">
            <div class="kayarine-benefit-card">
                <div class="kayarine-benefit-icon">✨</div>
                <h3>累積積分</h3>
                <p>每筆消費自動賺取積分</p>
            </div>
            <div class="kayarine-benefit-card">
                <div class="kayarine-benefit-icon">📅</div>
                <h3>輕鬆管理</h3>
                <p>在線管理及改期預約</p>
            </div>
            <div class="kayarine-benefit-card">
                <div class="kayarine-benefit-icon">💰</div>
                <h3>專屬折扣</h3>
                <p>升級享受會員等級優惠</p>
            </div>
        </div>

        <form id="kayarine-register-form" class="kayarine-register-form">
            <input type="hidden" name="action" value="kayarine_custom_register">
            <input type="hidden" name="redirect_to" value="<?php echo esc_attr( home_url( '/account/' ) ); ?>">
            <?php wp_nonce_field( 'kayarine_register_nonce', 'kayarine_register_nonce_field', false ); ?>
            
            <div class="kayarine-form-group">
                <label for="kayarine_reg_email">電子郵件 *</label>
                <input 
                    type="email" 
                    name="email" 
                    id="kayarine_reg_email" 
                    class="kayarine-form-input"
                    placeholder="輸入電子郵件"
                    required
                >
            </div>

            <div class="kayarine-form-group">
                <label for="kayarine_reg_username">用戶名 *</label>
                <input 
                    type="text" 
                    name="username" 
                    id="kayarine_reg_username" 
                    class="kayarine-form-input"
                    placeholder="輸入用戶名"
                    required
                >
            </div>

            <div class="kayarine-form-group">
                <label for="kayarine_reg_password">密碼 *</label>
                <input 
                    type="password" 
                    name="password" 
                    id="kayarine_reg_password" 
                    class="kayarine-form-input"
                    placeholder="輸入密碼（至少 8 個字元）"
                    required
                >
            </div>

            <div class="kayarine-form-group kayarine-checkbox-group">
                <label for="kayarine_reg_agree">
                    <input type="checkbox" name="agree" id="kayarine_reg_agree" required>
                    我已閱讀並同意<a href="<?php echo esc_url( get_privacy_policy_url() ); ?>" target="_blank">隱私政策</a>
                </label>
            </div>

            <button type="submit" class="kayarine-btn-submit">建立帳戶</button>
            <div id="kayarine-register-message" class="kayarine-form-message"></div>
        </form>

        <div class="kayarine-auth-footer">
            <p>已有帳戶？<button type="button" class="kayarine-switch-tab-btn" data-switch-to="login">直接登入</button></p>
        </div>
        <?php
    }

    public function handle_custom_login() {
        // Add logging for diagnostics
        error_log( 'Kayarine: Login attempt - POST data: ' . json_encode( $_POST ) );
        error_log( 'Kayarine: Nonce field received: ' . ( isset( $_POST['kayarine_login_nonce_field'] ) ? $_POST['kayarine_login_nonce_field'] : 'NOT SET' ) );
        
        // Verify nonce - but don't fail silently, log the actual status
        if ( isset( $_POST['kayarine_login_nonce_field'] ) ) {
            $nonce_result = wp_verify_nonce( $_POST['kayarine_login_nonce_field'], 'kayarine_login_nonce' );
            error_log( 'Kayarine: Nonce verification result: ' . $nonce_result );
            
            if ( ! $nonce_result ) {
                error_log( 'Kayarine: Nonce verification FAILED for login' );
                // Don't fail here - continue to show real error
            }
        } else {
            error_log( 'Kayarine: No nonce field in POST data' );
        }
        
        $username = isset( $_POST['log'] ) ? sanitize_user( $_POST['log'] ) : '';
        $password = isset( $_POST['pwd'] ) ? sanitize_text_field( $_POST['pwd'] ) : '';
        $redirect_to = isset( $_POST['redirect_to'] ) ? esc_url( $_POST['redirect_to'] ) : home_url( '/account/' );
        
        error_log( 'Kayarine: Login processing - username: ' . $username );
        
        if ( empty( $username ) || empty( $password ) ) {
            wp_send_json_error( array( 'message' => '請輸入用戶名和密碼' ) );
        }
        
        $user = wp_authenticate( $username, $password );
        
        if ( is_wp_error( $user ) ) {
            wp_send_json_error( array( 'message' => '用戶名或密碼不正確' ) );
        }
        
        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        
        wp_send_json_success( array(
            'message' => '登入成功，正在重定向...',
            'redirect' => $redirect_to
        ) );
    }

    public function handle_custom_register() {
        check_ajax_referer( 'kayarine_register_nonce', 'kayarine_register_nonce_field' );
        
        $email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';
        $username = isset( $_POST['username'] ) ? sanitize_user( $_POST['username'] ) : '';
        $password = isset( $_POST['password'] ) ? sanitize_text_field( $_POST['password'] ) : '';
        $redirect_to = isset( $_POST['redirect_to'] ) ? esc_url( $_POST['redirect_to'] ) : home_url( '/account/' );
        
        if ( empty( $email ) || !is_email( $email ) ) {
            wp_send_json_error( array( 'message' => '請輸入有效的電子郵件' ) );
        }
        
        if ( empty( $username ) || strlen( $username ) < 3 ) {
            wp_send_json_error( array( 'message' => '用戶名至少需要 3 個字元' ) );
        }
        
        if ( empty( $password ) || strlen( $password ) < 8 ) {
            wp_send_json_error( array( 'message' => '密碼至少需要 8 個字元' ) );
        }
        
        if ( username_exists( $username ) ) {
            wp_send_json_error( array( 'message' => '用戶名已存在' ) );
        }
        
        if ( email_exists( $email ) ) {
            wp_send_json_error( array( 'message' => '電子郵件已被註冊' ) );
        }
        
        $user_id = wp_create_user( $username, $password, $email );
        
        if ( is_wp_error( $user_id ) ) {
            wp_send_json_error( array( 'message' => '註冊失敗：' . $user_id->get_error_message() ) );
        }
        
        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, true );
        
        if ( class_exists( 'Kayarine_Membership' ) ) {
            update_user_meta( $user_id, Kayarine_Membership::META_POINTS, 0 );
            update_user_meta( $user_id, Kayarine_Membership::META_WALLET, 0 );
            update_user_meta( $user_id, Kayarine_Membership::META_SPEND, 0 );
        }
        
        wp_send_json_success( array(
            'message' => '註冊成功，正在重定向...',
            'redirect' => $redirect_to
        ) );
    }

    public function customize_account_menu( $items ) {
        if ( is_user_logged_in() ) {
            // Only show Kayarine Member Center and Logout
            // Hide ALL WooCommerce default menu items
            $new_items = array();
            
            // Always show dashboard (as Kayarine Member Center)
            if ( isset( $items['dashboard'] ) ) {
                $new_items['dashboard'] = '🏅 Kayarine 會員中心';
            }
            
            // Add Kayarine membership/progress section
            $new_items['kayarine-membership'] = '📊 我的進度';
            
            // Always show logout
            if ( isset( $items['customer-logout'] ) ) {
                $new_items['customer-logout'] = $items['customer-logout'];
            } elseif ( isset( $items['logout'] ) ) {
                $new_items['logout'] = $items['logout'];
            }
            
            return $new_items;
        }
        return $items;
    }

    public function render_membership_dashboard() {
        if ( ! is_user_logged_in() ) {
            return;
        }

        $user_id = get_current_user_id();
        $user = get_user_by( 'id', $user_id );
        
        $points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $tier = Kayarine_Membership::get_tier( $user_id );
        $spend = (float) get_user_meta( $user_id, Kayarine_Membership::META_SPEND, true );
        $tier_info = Kayarine_Membership::get_tier_info( $tier );
        
        $next_target = $tier_info['next'];
        $progress_percent = 0;
        $upgrade_msg = "您已是最高等級會員！";
        
        if ( $next_target > 0 ) {
            $progress_percent = min( 100, ($spend / $next_target) * 100 );
            $remaining = $next_target - $spend;
            $all_tiers = array('bronze', 'silver', 'gold');
            $current_idx = array_search( $tier, $all_tiers );
            $next_tier_slug = isset($all_tiers[$current_idx+1]) ? $all_tiers[$current_idx+1] : 'vip';
            $next_tier_info = Kayarine_Membership::get_tier_info( $next_tier_slug );
            $upgrade_msg = "再消費 <strong>HK$" . number_format($remaining) . "</strong> 即可升級" . $next_tier_info['label'] . "！";
        }
        ?>
        <div class="kayarine-membership-dashboard">
            <h2>會員進度</h2>
            
            <div class="kayarine-membership-header">
                <div class="kayarine-membership-avatar">👤</div>
                <div class="kayarine-membership-info">
                    <div class="kayarine-membership-name"><?php echo esc_html( $user->display_name ); ?></div>
                    <div class="kayarine-membership-tier"><?php echo $tier_info['label']; ?> <?php if($tier=='vip') echo '👑'; ?></div>
                </div>
            </div>

            <div class="kayarine-membership-stats">
                <div class="kayarine-stat-box">
                    <div class="kayarine-stat-label">現有積分</div>
                    <div class="kayarine-stat-value"><?php echo number_format($points); ?></div>
                </div>
            </div>

            <?php if ( $next_target > 0 ): ?>
            <div class="kayarine-membership-progress">
                <div class="kayarine-progress-label">
                    <span>目前消費: HK$<?php echo number_format($spend); ?></span>
                    <span>目標: HK$<?php echo number_format($next_target); ?></span>
                </div>
                <div class="kayarine-progress-bar-bg">
                    <div class="kayarine-progress-bar-fill" style="width: <?php echo $progress_percent; ?>%;"></div>
                </div>
                <div class="kayarine-progress-hint"><?php echo $upgrade_msg; ?></div>
            </div>
            <?php endif; ?>

            <div class="kayarine-membership-benefits">
                <h3>目前權益</h3>
                <ul>
                    <li>✓ 每筆消費享 2% 積分回饋</li>
                    <li>✓ 積分可折抵現金</li>
                    <li>✓ 早上 9:00 前免費改期</li>
                </ul>
            </div>
        </div>
        <?php
    }

    public function enqueue_custom_styles() {
        wp_enqueue_style( 'kayarine-booking-css' );
        wp_enqueue_script( 'jquery' );
        
        // Ensure ajaxurl is defined for JavaScript
        wp_localize_script( 'jquery', 'ajaxurl', admin_url( 'admin-ajax.php' ) );
        
        wp_add_inline_script( 'jquery', $this->get_ajax_handler_js() );
    }

    private function get_ajax_handler_js() {
        return <<<'JS'
(function($) {
    $(document).ready(function() {
        // Diagnostic: Check how many login forms exist
        var loginFormCount = $('#kayarine-login-form').length;
        console.log('[Kayarine Debug] Login forms found: ' + loginFormCount);
        
        // Diagnostic: Check nonce fields
        var nonceFields = $('input[name="kayarine_login_nonce_field"]');
        console.log('[Kayarine Debug] Nonce fields found: ' + nonceFields.length);
        nonceFields.each(function(i) {
            console.log('[Kayarine Debug] Nonce field ' + i + ' value: ' + $(this).val());
        });
        
        $('.kayarine-auth-tab-btn-orange').on('click', function(e) {
            e.preventDefault();
            var tabName = $(this).data('tab');
            
            $('.kayarine-auth-tab-btn-orange').removeClass('active');
            $('.kayarine-auth-panel-orange').removeClass('active');
            
            $(this).addClass('active');
            $('#kayarine-' + tabName + '-tab').addClass('active');
        });

        $('.kayarine-switch-tab-btn').on('click', function(e) {
            e.preventDefault();
            var targetTab = $(this).data('switch-to');
            
            $('.kayarine-auth-tab-btn-orange').removeClass('active');
            $('.kayarine-auth-panel-orange').removeClass('active');
            
            $('.kayarine-auth-tab-btn-orange[data-tab="' + targetTab + '"]').addClass('active');
            $('#kayarine-' + targetTab + '-tab').addClass('active');
        });

        $('#kayarine-login-form').on('submit', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $message = $('#kayarine-login-message');
            
            // Diagnostic: Detailed form data logging
            var nonceValue = $form.find('input[name="kayarine_login_nonce_field"]').val();
            console.log('[Kayarine Debug] Login form submitted');
            console.log('[Kayarine Debug] Form ID: ' + $form.attr('id'));
            console.log('[Kayarine Debug] Nonce value from this form: ' + nonceValue);
            console.log('[Kayarine Debug] Username: ' + $form.find('input[name="log"]').val());
            
            $btn.prop('disabled', true).text('登入中...');
            $message.html('').hide();
            
            var postData = {
                action: 'kayarine_custom_login',
                log: $form.find('input[name="log"]').val(),
                pwd: $form.find('input[name="pwd"]').val(),
                redirect_to: $form.find('input[name="redirect_to"]').val(),
                kayarine_login_nonce_field: nonceValue
            };
            
            console.log('[Kayarine Debug] POST data: ' + JSON.stringify(postData));
            
            $.post(ajaxurl, postData, function(response) {
                if (response.success) {
                    $message.html('<span style="color: #4caf50;">' + response.data.message + '</span>').show();
                    setTimeout(function() {
                        window.location.href = response.data.redirect;
                    }, 1000);
                } else {
                    $message.html('<span style="color: #f44336;">' + response.data.message + '</span>').show();
                    $btn.prop('disabled', false).text('登入');
                }
            }).fail(function() {
                $message.html('<span style="color: #f44336;">出錯，請重試</span>').show();
                $btn.prop('disabled', false).text('登入');
            });
        });

        $('#kayarine-register-form').on('submit', function(e) {
            e.preventDefault();
            var $form = $(this);
            var $btn = $form.find('button[type="submit"]');
            var $message = $('#kayarine-register-message');
            
            // Prevent double submission
            if ($btn.prop('disabled')) {
                return false;
            }
            
            // Diagnostic: Detailed form data logging
            var nonceValue = $form.find('input[name="kayarine_register_nonce_field"]').val();
            console.log('[Kayarine Debug] Register form submitted');
            console.log('[Kayarine Debug] Form ID: ' + $form.attr('id'));
            console.log('[Kayarine Debug] Nonce value from this form: ' + nonceValue);
            console.log('[Kayarine Debug] Email: ' + $form.find('input[name="email"]').val());
            
            $btn.prop('disabled', true).text('註冊中...');
            $message.html('').hide();
            
            var postData = {
                action: 'kayarine_custom_register',
                email: $form.find('input[name="email"]').val(),
                username: $form.find('input[name="username"]').val(),
                password: $form.find('input[name="password"]').val(),
                redirect_to: $form.find('input[name="redirect_to"]').val(),
                kayarine_register_nonce_field: nonceValue
            };
            
            console.log('[Kayarine Debug] POST data: ' + JSON.stringify(postData));
            
            $.post(ajaxurl, postData, function(response) {
                if (response.success) {
                    $message.html('<span style="color: #4caf50;">' + response.data.message + '</span>').show();
                    setTimeout(function() {
                        window.location.href = response.data.redirect;
                    }, 1000);
                } else {
                    $message.html('<span style="color: #f44336;">' + response.data.message + '</span>').show();
                    $btn.prop('disabled', false).text('建立帳戶');
                }
            }).fail(function() {
                $message.html('<span style="color: #f44336;">出錯，請重試</span>').show();
                $btn.prop('disabled', false).text('建立帳戶');
            });
        });
    });
})(jQuery);
JS;
    }

    private function get_custom_css() {
        return <<<'CSS'
.kayarine-auth-wrapper-orange {
    max-width: 700px;
    margin: 40px auto;
    padding: 20px;
}

.kayarine-auth-container-orange {
    background: #ffffff;
    border-radius: 12px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    overflow: hidden;
}

.kayarine-auth-header-orange {
    background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%);
    padding: 30px;
    text-align: center;
    color: white;
}

.kayarine-auth-header-orange h1 {
    margin: 0 0 8px 0;
    font-size: 1.8rem;
    font-weight: 700;
}

.kayarine-auth-header-orange p {
    margin: 0;
    font-size: 0.95rem;
    opacity: 0.95;
}

.kayarine-auth-tabs-orange {
    display: flex;
    border-bottom: 2px solid #f0f0f0;
    background: #fafafa;
}

.kayarine-auth-tab-btn-orange {
    flex: 1;
    padding: 15px 20px;
    border: none;
    background: transparent;
    cursor: pointer;
    font-size: 0.95rem;
    font-weight: 600;
    color: #999;
    transition: all 0.3s ease;
    border-bottom: 3px solid transparent;
    margin-bottom: -2px;
}

.kayarine-auth-tab-btn-orange:hover {
    color: #2d3748;
    border-bottom-color: #e2e8f0;
    background: transparent;
}

.kayarine-auth-tab-btn-orange.active {
    color: #2d3748;
    border-bottom-color: #FF8C42;
    background: #ffffff;
}

.kayarine-auth-panel-orange {
    display: none;
    opacity: 0;
}

.kayarine-auth-panel-orange.active {
    display: block;
    opacity: 1;
}

.kayarine-auth-panel-content-orange {
    padding: 30px;
}

.kayarine-auth-panel-content-orange h2 {
    margin-top: 0;
    font-size: 1.5rem;
    color: #2d3748;
    margin-bottom: 10px;
}

.kayarine-auth-subtitle {
    color: #666 !important;
    font-size: 0.95rem !important;
    margin-bottom: 20px !important;
}

.kayarine-form-group {
    margin-bottom: 15px;
}

.kayarine-form-group label {
    display: block !important;
    margin-bottom: 6px !important;
    font-weight: 600 !important;
    color: #333 !important;
    font-size: 0.9rem !important;
}

.kayarine-form-input {
    width: 100% !important;
    padding: 10px 12px !important;
    border: 1px solid #ddd !important;
    border-radius: 6px !important;
    font-size: 1rem !important;
    box-sizing: border-box !important;
    transition: all 0.2s ease !important;
}

.kayarine-form-input:focus {
    border-color: #FF8C42 !important;
    outline: none !important;
    box-shadow: 0 0 0 3px rgba(255, 140, 66, 0.1) !important;
}

.kayarine-checkbox-group {
    display: flex;
    align-items: center;
}

.kayarine-checkbox-group label {
    display: flex !important;
    align-items: center !important;
    gap: 6px !important;
    margin-bottom: 0 !important;
    font-weight: normal !important;
}

.kayarine-checkbox-group input[type="checkbox"] {
    accent-color: #FF8C42 !important;
    cursor: pointer !important;
}

.kayarine-btn-submit {
    width: 100% !important;
    padding: 12px 20px !important;
    background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%) !important;
    color: white !important;
    border: none !important;
    border-radius: 6px !important;
    font-weight: 700 !important;
    font-size: 1rem !important;
    cursor: pointer !important;
    transition: all 0.3s ease !important;
    box-shadow: 0 2px 8px rgba(255, 140, 66, 0.25) !important;
}

.kayarine-btn-submit:hover {
    transform: translateY(-1px) !important;
    box-shadow: 0 4px 12px rgba(255, 140, 66, 0.35) !important;
}

.kayarine-btn-submit:disabled {
    opacity: 0.7 !important;
    cursor: not-allowed !important;
}

.kayarine-form-message {
    display: none;
    margin-top: 15px;
    padding: 10px;
    border-radius: 4px;
    text-align: center;
}

.kayarine-benefits-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
    margin-bottom: 20px;
}

.kayarine-benefit-card {
    padding: 15px;
    background: #f9f9f9;
    border-radius: 8px;
    text-align: center;
    border: 1px solid #e0e0e0;
    transition: all 0.2s ease;
}

.kayarine-benefit-card:hover {
    border-color: #FF8C42;
    background: rgba(255, 140, 66, 0.05);
}

.kayarine-benefit-icon {
    font-size: 2rem;
    margin-bottom: 8px;
    display: block;
}

.kayarine-benefit-card h3 {
    font-size: 0.95rem;
    color: #333;
    margin: 0 0 6px 0;
    font-weight: 700;
}

.kayarine-benefit-card p {
    font-size: 0.8rem;
    color: #666;
    margin: 0;
    line-height: 1.4;
}

.kayarine-auth-footer {
    padding: 0 30px 30px 30px;
    text-align: center;
    font-size: 0.9rem;
    color: #666;
}

.kayarine-auth-panel-content-orange a {
    color: #FF8C42 !important;
    text-decoration: none !important;
}

.kayarine-auth-panel-content-orange a:hover {
    color: #FF7A3D !important;
    text-decoration: underline !important;
}

.kayarine-switch-tab-btn {
    background: none !important;
    border: none !important;
    color: #FF8C42 !important;
    font-weight: 700 !important;
    cursor: pointer !important;
    text-decoration: none !important;
    font-size: 0.9rem !important;
    padding: 0 !important;
    margin-left: 4px !important;
}

.kayarine-switch-tab-btn:hover {
    color: #FF7A3D !important;
    text-decoration: underline !important;
}

.kayarine-membership-dashboard {
    background: #f9f9f9;
    padding: 30px;
    border-radius: 12px;
}

.kayarine-membership-dashboard h2 {
    margin-top: 0;
    color: #2d3748;
    font-size: 1.5rem;
}

.kayarine-membership-header {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 30px;
    padding: 20px;
    background: white;
    border-radius: 8px;
}

.kayarine-membership-avatar {
    width: 60px;
    height: 60px;
    background: linear-gradient(135deg, #FF8C42 0%, #FF7A3D 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.8rem;
    color: white;
    box-shadow: 0 2px 8px rgba(255, 140, 66, 0.3);
    flex-shrink: 0;
}

.kayarine-membership-info {
    flex: 1;
}

.kayarine-membership-name {
    font-size: 1.1rem;
    font-weight: 700;
    color: #2d3748;
}

.kayarine-membership-tier {
    font-size: 0.9rem;
    color: #FF8C42;
    font-weight: 600;
    margin-top: 4px;
}

.kayarine-membership-stats {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
    margin-bottom: 30px;
}

.kayarine-stat-box {
    background: white;
    padding: 15px;
    border-radius: 8px;
    text-align: center;
}

.kayarine-stat-label {
    font-size: 0.8rem;
    color: #718096;
    margin-bottom: 4px;
}

.kayarine-stat-value {
    font-size: 1.3rem;
    font-weight: 800;
    color: #FF8C42;
}

.kayarine-membership-progress {
    background: white;
    padding: 20px;
    border-radius: 8px;
    margin-bottom: 30px;
}

.kayarine-progress-label {
    display: flex;
    justify-content: space-between;
    font-size: 0.85rem;
    margin-bottom: 10px;
    color: #718096;
}

.kayarine-progress-bar-bg {
    width: 100%;
    height: 8px;
    background: #edf2f7;
    border-radius: 4px;
    overflow: hidden;
    margin-bottom: 10px;
}

.kayarine-progress-bar-fill {
    height: 100%;
    background: linear-gradient(90deg, #FF8C42 0%, #FF7A3D 100%);
    border-radius: 4px;
    transition: width 0.5s ease;
}

.kayarine-progress-hint {
    font-size: 0.85rem;
    color: #FF8C42;
    text-align: center;
}

.kayarine-membership-benefits {
    background: white;
    padding: 20px;
    border-radius: 8px;
}

.kayarine-membership-benefits h3 {
    margin-top: 0;
    font-size: 1rem;
    color: #2d3748;
}

.kayarine-membership-benefits ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.kayarine-membership-benefits li {
    padding: 8px 0;
    color: #4a5568;
    font-size: 0.95rem;
}

@media (max-width: 768px) {
    .kayarine-auth-wrapper-orange {
        margin: 20px auto;
        padding: 10px;
    }

    .kayarine-auth-header-orange {
        padding: 20px;
    }

    .kayarine-auth-header-orange h1 {
        font-size: 1.5rem;
    }

    .kayarine-auth-tab-btn-orange {
        padding: 12px 16px;
        font-size: 0.85rem;
    }

    .kayarine-auth-panel-content-orange {
        padding: 20px;
    }

    .kayarine-benefits-grid {
        grid-template-columns: 1fr;
    }

    .kayarine-membership-header {
        flex-direction: column;
        text-align: center;
    }

    .kayarine-membership-stats {
        grid-template-columns: 1fr;
    }
}

@media (max-width: 480px) {
    .kayarine-auth-wrapper-orange {
        margin: 10px auto;
        padding: 5px;
    }

    .kayarine-auth-header-orange {
        padding: 15px;
    }

    .kayarine-auth-header-orange h1 {
        font-size: 1.3rem;
    }

    .kayarine-auth-tab-btn-orange {
        padding: 10px 12px;
        font-size: 0.8rem;
    }

    .kayarine-auth-panel-content-orange {
        padding: 15px;
    }

    .kayarine-auth-panel-content-orange input {
        font-size: 16px !important;
    }
}
CSS;
    }
}

// Initialize on plugins_loaded to ensure all dependencies are ready
add_action( 'plugins_loaded', function() {
    // Initialize regardless of WooCommerce, as login/register works independently
    new Kayarine_WooCommerce_Customizer();
}, 20 );
