#!/bin/bash

################################################################################
# Kayarine SSH 快速部署腳本
# 使用：./deploy.sh [環境] [選項]
# 選項：--fast, --clear-cache, --files
################################################################################

set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
CONFIG_FILE="$PROJECT_DIR/deploy.conf"

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# 函數定義
log_info() {
    echo -e "${BLUE}[ℹ]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
    exit 1
}

# 檢查配置文件
if [ ! -f "$CONFIG_FILE" ]; then
    log_error "配置文件不存在: $CONFIG_FILE"
fi

# 加載配置
source "$CONFIG_FILE"

# 參數解析
ENVIRONMENT="${1:-$ENVIRONMENT}"
FAST_MODE=false
CLEAR_CACHE=false
SPECIFIC_FILES=()

shift || true
for arg in "$@"; do
    case $arg in
        --fast) FAST_MODE=true ;;
        --clear-cache) CLEAR_CACHE=true ;;
        --files)
            shift || true
            while [ $# -gt 0 ] && [[ ! "$1" =~ ^-- ]]; do
                SPECIFIC_FILES+=("$1")
                shift || true
            done
            ;;
    esac
done

# 標題
echo -e "${BLUE}"
echo "╔═══════════════════════════════════════════════╗"
echo "║   Kayarine SSH 快速部署"
echo "║   環境: $ENVIRONMENT"
echo "║   時間: $(date '+%Y-%m-%d %H:%M:%S')"
echo "╚═══════════════════════════════════════════════╝"
echo -e "${NC}\n"

# 驗證 SSH 連接
log_info "驗證 SSH 連接 ($DEPLOY_USER@$DEPLOY_HOST:$DEPLOY_PORT)..."
if ssh -i "$DEPLOY_KEY" -p "$DEPLOY_PORT" -q "$DEPLOY_USER@$DEPLOY_HOST" "echo OK" 2>/dev/null; then
    log_success "SSH 連接成功"
else
    log_error "SSH 連接失敗，請檢查配置"
fi

# 跳過本地備份（已禁用）
BACKUP_FILE=""

# 跳過遠程備份（已禁用）
REMOTE_BACKUP=""

# 上傳文件
log_info "上傳修改文件..."

if [ ${#SPECIFIC_FILES[@]} -gt 0 ]; then
    # 上傳特定文件
    for file in "${SPECIFIC_FILES[@]}"; do
        SOURCE="$SCRIPT_DIR/includes/$file"
        if [ -f "$SOURCE" ]; then
            scp -i "$DEPLOY_KEY" -P "$DEPLOY_PORT" -q "$SOURCE" \
                "$DEPLOY_USER@$DEPLOY_HOST:$PLUGIN_PATH/includes/$file"
            log_success "已上傳: includes/$file"
        else
            log_warning "文件不存在: $file"
        fi
    done
else
    # 上傳整個目錄
    if command -v rsync &> /dev/null; then
        rsync -avz --delete \
            -e "ssh -i $DEPLOY_KEY -p $DEPLOY_PORT" \
            "$SCRIPT_DIR/" "$DEPLOY_USER@$DEPLOY_HOST:$PLUGIN_PATH/" \
            --exclude='*.tar.gz' --exclude='.git' --exclude='node_modules' > /dev/null 2>&1
        log_success "所有文件已上傳（使用 rsync）"
    else
        # 備選：使用 scp
        tar -czf /tmp/kayarine_temp.tar.gz -C "$SCRIPT_DIR" .
        scp -i "$DEPLOY_KEY" -P "$DEPLOY_PORT" -q /tmp/kayarine_temp.tar.gz \
            "$DEPLOY_USER@$DEPLOY_HOST:/tmp/"
        
        EXTRACT_CMD="
            cd '$PLUGIN_PATH'
            tar -xzf /tmp/kayarine_temp.tar.gz
            rm /tmp/kayarine_temp.tar.gz
        "
        ssh -i "$DEPLOY_KEY" -p "$DEPLOY_PORT" "$DEPLOY_USER@$DEPLOY_HOST" "$EXTRACT_CMD" 2>/dev/null
        rm /tmp/kayarine_temp.tar.gz
        log_success "所有文件已上傳（使用 tar+scp）"
    fi
fi

# 遠程驗證
log_info "驗證遠程文件..."

VERIFY_CMD="
    PHP_CHECK=\$(php -l '$PLUGIN_PATH/includes/class-kayarine-cart-manager.php' 2>&1)
    if [[ \$PHP_CHECK == *'No syntax errors'* ]]; then
        echo 'PHP 語法 ✓'
    else
        echo 'PHP 語法錯誤'
        exit 1
    fi
    
    if [ -f '$PLUGIN_PATH/kayarine-booking.php' ]; then
        echo '主文件 ✓'
    else
        echo '主文件丟失'
        exit 1
    fi
"

if ssh -i "$DEPLOY_KEY" -p "$DEPLOY_PORT" "$DEPLOY_USER@$DEPLOY_HOST" "$VERIFY_CMD" 2>/dev/null; then
    log_success "遠程驗證通過"
else
    log_warning "遠程驗證失敗（可能缺少 PHP）"
fi

# 清除緩存
if [ "$CLEAR_CACHE" = true ]; then
    log_info "清除 WordPress 緩存..."
    
    CACHE_CMD="
        cd '$WP_PATH'
        if command -v wp &> /dev/null; then
            wp cache flush
            wp plugin deactivate kayarine-booking --allow-root 2>/dev/null || true
            wp plugin activate kayarine-booking --allow-root 2>/dev/null || true
            echo '✓ 緩存已清除，插件已重新啟用'
        else
            echo '⚠ wp-cli 未安裝'
        fi
    "
    
    if ssh -i "$DEPLOY_KEY" -p "$DEPLOY_PORT" "$DEPLOY_USER@$DEPLOY_HOST" "$CACHE_CMD" 2>/dev/null; then
        log_success "緩存已清除"
    else
        log_warning "緩存清除失敗（wp-cli 未安裝或未啟用）"
    fi
fi

# Slack 通知
if [ -n "$SLACK_WEBHOOK" ]; then
    log_info "發送 Slack 通知..."
    
    DEPLOY_STATUS="✅ 部署成功"
    DEPLOY_TIME=$(date '+%Y-%m-%d %H:%M:%S')
    
    curl -X POST "$SLACK_WEBHOOK" \
        -H 'Content-Type: application/json' \
        -d "{
            \"text\": \"$DEPLOY_STATUS\",
            \"attachments\": [{
                \"color\": \"good\",
                \"fields\": [
                    {\"title\": \"環境\", \"value\": \"$ENVIRONMENT\", \"short\": true},
                    {\"title\": \"時間\", \"value\": \"$DEPLOY_TIME\", \"short\": true},
                    {\"title\": \"遠程備份\", \"value\": \"/tmp/kayarine_backups/$REMOTE_BACKUP\", \"short\": false}
                ]
            }]
        }" > /dev/null 2>&1
    
    log_success "Slack 通知已發送"
fi

# 完成
echo -e "\n${GREEN}"
echo "╔═══════════════════════════════════════════════╗"
echo "║   ✓ 部署完成"
echo "║   部署時間: $(date '+%Y-%m-%d %H:%M:%S')"
echo "╚═══════════════════════════════════════════════╝"
echo -e "${NC}"

echo ""
