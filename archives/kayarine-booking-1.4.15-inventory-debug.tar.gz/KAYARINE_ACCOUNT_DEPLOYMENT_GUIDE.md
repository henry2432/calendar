# Kayarine 會員帳戶 UI - 完整部署指南

## 📋 概述

已完成對 `class-kayarine-woocommerce-customizer.php` 的重寫，實現了：
- ✅ 自定義 `[kayarine_account]` Shortcode
- ✅ 標籤頁式登入/免費註冊界面
- ✅ 橙色主題設計 (#FF8C42, #FF7A3D)
- ✅ 會員進度儀表板
- ✅ 響應式設計（768px、480px 斷點）
- ✅ AJAX 表單提交和驗證
- ✅ WooCommerce 集成

---

## 🚀 部署方法選擇

由於 SSH 連接目前無法使用，請選擇以下其中一個方法上傳文件：

### 方法 1️⃣：WordPress 後台文件管理器（推薦）

**優點**：無需其他工具，最簡單

#### 步驟：

1. **登入 WordPress 後台**
   - 進入 wp-admin（例如：`https://kayarine.com/wp-admin`）
   - 使用管理員帳號登入

2. **進入文件管理**
   - 側邊菜單 → **工具** → **文件管理器**（如果有安裝）
   - 或進入 **外掛** → **外掛編輯器**（不推薦，但可用）

3. **上傳文件**
   - 導航至 `wp-content/plugins/kayarine-booking/includes/`
   - 上傳 `class-kayarine-woocommerce-customizer.php`

4. **驗證上傳**
   - 確認文件出現在正確的目錄中
   - 檢查文件大小是否完整（約 30 KB）

---

### 方法 2️⃣：FTP/SFTP 客戶端

**優點**：可靠、適合大文件、可批量上傳

#### 工具推薦：
- **FileZilla**（免費，跨平台）
- **Transmit**（macOS）
- **WinSCP**（Windows）

#### 步驟：

1. **連接伺服器**
   ```
   主機: 35.241.107.233 (或你的 kayarine.com)
   用戶名: kayarine_server
   密碼: [使用你的密碼] 或使用 SSH 密鑰
   埠: 22 (SSH) 或 21 (FTP)
   ```

2. **導航至目標目錄**
   ```
   /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/
   ```
   或
   ```
   /var/www/html/wp-content/plugins/kayarine-booking/includes/
   ```

3. **上傳文件**
   - 拖動 `class-kayarine-woocommerce-customizer.php` 到遠程目錄
   - 確保文件權限設置為 644（FTP 客戶端可設置）

4. **驗證完成**
   - 在 FTP 中查看文件列表確認上傳成功

---

### 方法 3️⃣：GCP Web 控制台

**優點**：無需額外軟件，直接在網頁操作

#### 步驟：

1. **進入 GCP 控制台**
   - 訪問 `console.cloud.google.com`
   - 選擇 Kayarine 項目

2. **使用序列埠連接**
   - 計算引擎 → 實例 → `wordpress-2025-vm`
   - 點擊 **序列埠 1 (GCP Tools)**
   - 這會打開一個 Web 終端

3. **上傳並部署**
   ```bash
   # 創建臨時目錄
   mkdir -p /tmp/kayarine-deploy
   cd /tmp/kayarine-deploy
   
   # 使用 nano 或 vi 創建文件（複製本地內容粘貼）
   nano class-kayarine-woocommerce-customizer.php
   # [粘貼整個文件內容]
   # 按 Ctrl+X, 然後 Y, 再按 Enter 保存
   
   # 移動到目標位置
   sudo mv class-kayarine-woocommerce-customizer.php \
       /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/
   
   # 設置權限
   sudo chown daemon:daemon \
       /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/class-kayarine-woocommerce-customizer.php
   sudo chmod 644 \
       /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/class-kayarine-woocommerce-customizer.php
   ```

---

### 方法 4️⃣：使用 WordPress 外掛上傳

**優點**：適合快速迭代，不影響其他文件

#### 步驟：

1. **在 WordPress 後台**
   - 進入 **外掛** → **添加新外掛**
   - 搜索「Code Snippets」或「Advanced Code」外掛
   - 安裝並激活

2. **創建代碼片段**
   - 進入外掛設置
   - 複製 `kayarine-booking/includes/UPLOAD_HELPER.php` 的內容
   - 作為新代碼片段添加

3. **運行驗證**
   - 訪問外掛提供的驗證頁面
   - 確認文件已正確部署

---

## ✅ 部署後驗證

### 1️⃣ 檢查文件存在
```bash
# 通過 FTP 或 SSH 確認文件在正確位置
ls -la /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/class-kayarine-woocommerce-customizer.php
# 應顯示：-rw-r--r-- ... class-kayarine-woocommerce-customizer.php
```

### 2️⃣ 啟用 WordPress 調試日誌
編輯 `wp-config.php`（通過 FTP 或 WP 文件管理器）：

```php
// 在文件末尾添加
define( 'WP_DEBUG', true );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
```

### 3️⃣ 檢查 PHP 語法錯誤
訪問 WordPress 後台，檢查：
- `wp-content/debug.log`（如果啟用了 WP_DEBUG）
- 尋找任何 Parse error 或 Fatal error

### 4️⃣ 創建 /account/ 頁面

在 WordPress 後台：

1. **頁面** → **新增**
2. **標題**：會員帳戶
3. **永久連結**：`account`
4. **內容**：
   ```
   [kayarine_account]
   ```
5. **發布**

### 5️⃣ 重新整理固定連結

1. **設定** → **固定連結**
2. 點擊 **保存更改**（即使沒有修改任何內容）
3. 這會刷新 WooCommerce 的自定義端點

### 6️⃣ 測試 Shortcode

訪問 `https://kayarine.com/account/`

#### 預期結果：

**未登入用戶：**
```
✨ Kayarine 會員中心
登入或註冊以管理您的預約

[🔐 會員登入 按鈕] [✨ 免費註冊 按鈕]

登入表單：
- 電子郵件或用戶名
- 密碼
- 記住我 (checkbox)
- [登入] 按鈕

益處卡片：
✨ 累積積分
📅 輕鬆管理
💰 專屬折扣
```

**已登入用戶：**
```
WooCommerce 帳戶導航
+ 🏅 會員進度 (新增菜單項)

會員進度儀表板：
- 用戶頭像 + 名稱 + 會員等級
- 現有積分 | 儲值金
- 消費進度條
- 目前權益列表
```

---

## 🐛 常見問題排除

### 問題 1️⃣：Shortcode 顯示為純文本 `[kayarine_account]`

**可能原因：**
- 文件未正確上傳
- PHP 語法錯誤
- 插件未激活

**解決方案：**
```bash
# 1. 驗證文件存在且權限正確
ls -l /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/class-kayarine-woocommerce-customizer.php

# 2. 檢查 PHP 語法
php -l /opt/bitnami/wordpress/wp-content/plugins/kayarine-booking/includes/class-kayarine-woocommerce-customizer.php

# 3. 檢查 debug.log
tail -50 /opt/bitnami/wordpress/wp-content/debug.log

# 4. 在 WP 後台重新激活外掛
# 外掛 → Kayarine Booking → 停用 → 激活
```

### 問題 2️⃣：標籤頁無法切換

**檢查點：**
- 瀏覽器開發者工具（F12）→ 控制台
- 查看是否有 JavaScript 錯誤
- 確認 jQuery 已加載

```javascript
// 在瀏覽器控制台測試
console.log(jQuery); // 應顯示 jQuery 對象
$('.kayarine-auth-tab-btn-orange').length; // 應大於 0
```

### 問題 3️⃣：顏色不是橙色

**解決方案：**
```bash
# 清除 WordPress 快取
# 1. 進入 WP 後台 → 工具 → 清除快取（如使用快取插件）
# 2. 清除瀏覽器快取：Ctrl+Shift+Delete
# 3. 強制刷新頁面：Ctrl+F5
```

### 問題 4️⃣：登入/註冊表單無法提交

**檢查：**
- 瀏覽器控制台是否有 AJAX 錯誤
- WordPress nonce 是否正確生成
- `/wp-admin/admin-ajax.php` 是否可訪問

```javascript
// 測試 AJAX
jQuery.post(ajaxurl, {action: 'heartbeat'}, function(response) {
    console.log('AJAX 正常工作', response);
});
```

---

## 📁 文件結構

```
kayarine-booking/
├── kayarine-booking.php (主文件，已更新引入 customizer)
├── includes/
│   ├── class-kayarine-woocommerce-customizer.php (✨ 新文件 - 980行)
│   ├── class-kayarine-membership.php
│   ├── class-kayarine-booking.php
│   └── ... (其他類文件)
└── assets/
    ├── css/style.css (已更新，包含 customizer 樣式)
    └── js/script.js
```

---

## 🔍 驗證清單

部署完成後，請確認以下項目：

- [ ] 文件已上傳到 `includes/class-kayarine-woocommerce-customizer.php`
- [ ] 文件權限設置為 644（可讀）
- [ ] 沒有 PHP 語法錯誤（查看 debug.log）
- [ ] `[kayarine_account]` Shortcode 在 /account/ 頁面上顯示（不是純文本）
- [ ] 未登入用戶看到登入/註冊標籤頁
- [ ] 已登入用戶看到帳戶儀表板
- [ ] 所有按鈕和鏈接使用橙色主題 (#FF8C42)
- [ ] 表單提交正常工作（檢查瀏覽器控制台無錯誤）
- [ ] 手機端 (480px) 響應式正常
- [ ] 會員進度顯示用戶積分、錢包、消費進度

---

## 📞 支持信息

如遇到問題，請檢查：

1. **WordPress 錯誤日誌**
   ```
   /opt/bitnami/wordpress/wp-content/debug.log
   ```

2. **伺服器日誌**（Apache/Nginx）
   ```
   /opt/bitnami/apache2/logs/error_log
   # 或
   /var/log/nginx/error.log
   ```

3. **PHP-FPM 日誌**（如使用）
   ```
   /opt/bitnami/php/logs/php-fpm.log
   ```

4. **瀏覽器開發者工具**
   - F12 開啟開發者工具
   - 查看 Console（控制台）標籤頁
   - 查看 Network（網絡）標籤頁

---

## 📝 版本信息

- **部署日期**：2026-01-27
- **Kayarine 版本**：1.4.1
- **PHP 要求**：7.2+
- **WordPress 要求**：5.0+
- **WooCommerce**：必需

---

## 🎨 設計特點回顾

### 色彩方案
- **主色**：橙色 #FF8C42
- **深色變體**：#FF7A3D（懸停狀態）
- **背景**：白色 #ffffff
- **文本**：深灰色 #2d3748

### 響應式斷點
```css
- 桌面：900px+（完整佈局）
- 平板：768px-899px（優化標籤寬度）
- 手機：480px-767px（堆疊佈局）
- 小屏幕：<480px（極小化設計）
```

### Shortcode 使用
```
[kayarine_account]
```

### 功能概述
1. **自動狀態檢測**：根據用戶登入狀態自動顯示不同內容
2. **標籤頁系統**：登入 ↔ 免費註冊 平滑切換
3. **AJAX 提交**：無頁面刷新的表單提交
4. **安全驗證**：Nonce 驗證、數據清理、錯誤處理
5. **會員儀表板**：顯示用戶積分、錢包、升級進度

---

祝部署順利！如有任何問題，請參考上述故障排除部分或檢查 WordPress 調試日誌。
