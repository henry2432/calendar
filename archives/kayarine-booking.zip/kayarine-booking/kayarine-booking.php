<?php
/**
 * Plugin Name: Kayarine Booking
 * Plugin URI: https://www.kayarine.com.hk
 * Description: Custom booking system for Kayarine (Single/Double Kayaks, SUP, Add-ons)
 * Version: 1.4.0
 * Author: Kayarine Dev Team
 * Text Domain: kayarine-booking
 */

if ( ! defined( 'ABSPATH' ) ) {
 exit;
}

// Define Constants
define( 'KAYARINE_BOOKING_VERSION', '1.4.1' );
define( 'KAYARINE_BOOKING_PATH', plugin_dir_path( __FILE__ ) );
define( 'KAYARINE_BOOKING_URL', plugin_dir_url( __FILE__ ) );

// Include Main Classes
require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-booking.php';
require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-member-dashboard-v2.php';
require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-woocommerce-customizer.php';

// Initialize Plugin
function kayarine_booking_init() {
	$plugin = new Kayarine_Booking();
	$plugin->run();
}
add_action( 'plugins_loaded', 'kayarine_booking_init' );

// Internal Availability Check (AJAX)
// No longer proxies to Flask/Python. Now queries WP DB directly.
add_action( 'wp_ajax_kayarine_proxy_check', 'kayarine_check_stock_internal' );
add_action( 'wp_ajax_nopriv_kayarine_proxy_check', 'kayarine_check_stock_internal' );

function kayarine_check_stock_internal() {
    $date = isset($_REQUEST['date']) ? sanitize_text_field($_REQUEST['date']) : '';
    if ( ! $date ) {
        wp_send_json_error( array( 'message' => 'No date provided' ) );
    }

    try {
        // Use new Inventory Class to check availability
        $availability = Kayarine_Inventory::get_availability( $date );
        
        // Format response to match what the frontend JS expects
        // JS expects: { status: 'success', availability: { ID: { remaining: X, ... } } }
        $response = array(
            'status' => 'success',
            'date'   => $date,
            'availability' => $availability
        );

        wp_send_json( $response );

    } catch ( Exception $e ) {
        wp_send_json_error( array( 'message' => 'System Error: ' . $e->getMessage() ) );
    }
}
