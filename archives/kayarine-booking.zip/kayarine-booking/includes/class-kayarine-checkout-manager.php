<?php
/**
 * Kayarine Checkout Manager
 * Handles Points Redemption and Wallet Usage at Checkout.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Kayarine_Checkout_Manager {

    public function __construct() {
        // Display Points/Wallet UI in Checkout
        add_action( 'woocommerce_review_order_before_payment', array( $this, 'render_loyalty_options' ) );
        
        // Process AJAX actions for redemption
        add_action( 'wp_ajax_kayarine_apply_points', array( $this, 'ajax_apply_points' ) );
        add_action( 'wp_ajax_nopriv_kayarine_apply_points', array( $this, 'ajax_apply_points' ) );
        add_action( 'wp_ajax_kayarine_apply_wallet', array( $this, 'ajax_apply_wallet' ) );
        add_action( 'wp_ajax_nopriv_kayarine_apply_wallet', array( $this, 'ajax_apply_wallet' ) );

        // Calculate Totals (Discount)
        add_action( 'woocommerce_cart_calculate_fees', array( $this, 'apply_discounts' ) );
        
        // Remove discounts if order cancelled/failed? (Not needed for fees usually)
        // Deduct points/wallet on successful payment? 
        // Actually, we deduct when order is *placed* (processing) to prevent double usage?
        // Or deduct on 'completed'? 
        // Standard practice: Deduct on 'processing' (payment received). 
        add_action( 'woocommerce_order_status_processing', array( $this, 'deduct_loyalty_balance' ) );
        add_action( 'woocommerce_order_status_completed', array( $this, 'deduct_loyalty_balance' ) );
    }

    /**
     * Render UI above Payment Methods
     */
    public function render_loyalty_options() {
        if ( ! is_user_logged_in() ) {
            echo '<div class="woocommerce-info">登入後可使用會員積分或儲值金。 <a href="' . get_permalink( get_option('woocommerce_myaccount_page_id') ) . '">按此登入</a></div>';
            return;
        }

        $user_id = get_current_user_id();
        $points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $wallet = (float) get_user_meta( $user_id, Kayarine_Membership::META_WALLET, true );
        $tier = Kayarine_Membership::get_tier( $user_id );
        
        // Get applied sessions
        $applied_points = WC()->session->get( 'kayarine_points_applied', 0 );
        $applied_wallet = WC()->session->get( 'kayarine_wallet_applied', 0 );
        
        // Calculate max usable (Cart Total)
        $cart_total = WC()->cart->get_subtotal() + WC()->cart->get_shipping_total(); 
        // Note: get_total() includes fees, so circular dependency if not careful. Use subtotal.
        
        ?>
        <div id="kayarine-loyalty-checkout" class="kayarine-booking-card" style="padding: 15px; margin-bottom: 20px; border-color: #ed8936;">
            <h4 style="margin-top:0;">會員優惠 (<?php echo Kayarine_Membership::get_tier_info($tier)['label']; ?>)</h4>
            
            <!-- Points Section -->
            <div class="kb-checkout-section" style="margin-bottom: 15px;">
                <label>
                    <input type="checkbox" id="use_points_check" <?php checked( $applied_points > 0 ); ?>>
                    使用積分折抵 (現有: <?php echo $points; ?> 分)
                </label>
                <div id="points_input_wrap" style="display: <?php echo $applied_points > 0 ? 'block' : 'none'; ?>; margin-top: 5px; padding-left: 20px;">
                    <input type="number" id="points_amount" value="<?php echo $applied_points ? $applied_points : ''; ?>" placeholder="輸入積分 (1分 = $1)" max="<?php echo $points; ?>" style="width: 150px;">
                    <button type="button" class="button" id="apply_points_btn">套用</button>
                    <p class="description" style="font-size: 12px;">每 1 積分可折抵 HK$1。</p>
                </div>
            </div>

            <!-- Wallet Section -->
            <div class="kb-checkout-section">
                <label>
                    <input type="checkbox" id="use_wallet_check" <?php checked( $applied_wallet > 0 ); ?>>
                    使用儲值金付款 (餘額: $<?php echo number_format($wallet, 2); ?>)
                </label>
                <div id="wallet_input_wrap" style="display: <?php echo $applied_wallet > 0 ? 'block' : 'none'; ?>; margin-top: 5px; padding-left: 20px;">
                    <input type="number" id="wallet_amount" value="<?php echo $applied_wallet ? $applied_wallet : ''; ?>" placeholder="輸入金額" max="<?php echo $wallet; ?>" style="width: 150px;">
                    <button type="button" class="button" id="apply_wallet_btn">套用</button>
                </div>
            </div>
            
            <div id="loyalty_message"></div>
        </div>

        <script>
        jQuery(document).ready(function($) {
            // Toggle Visibility
            $('#use_points_check').change(function() {
                $('#points_input_wrap').toggle(this.checked);
                if(!this.checked) trigger_ajax('points', 0);
            });
            $('#use_wallet_check').change(function() {
                $('#wallet_input_wrap').toggle(this.checked);
                if(!this.checked) trigger_ajax('wallet', 0);
            });

            // Apply Buttons
            $('#apply_points_btn').click(function() {
                var amt = $('#points_amount').val();
                trigger_ajax('points', amt);
            });
            $('#apply_wallet_btn').click(function() {
                var amt = $('#wallet_amount').val();
                trigger_ajax('wallet', amt);
            });

            function trigger_ajax(type, amount) {
                $('#loyalty_message').text('處理中...').css('color', '#666');
                $('body').trigger('update_checkout'); // Lock checkout

                $.ajax({
                    type: 'POST',
                    url: '<?php echo admin_url('admin-ajax.php'); ?>',
                    data: {
                        action: 'kayarine_apply_' + type,
                        amount: amount
                    },
                    success: function(response) {
                        if(response.success) {
                            $('#loyalty_message').text(response.data.message).css('color', 'green');
                            $('body').trigger('update_checkout'); // Refresh totals
                        } else {
                            $('#loyalty_message').text(response.data.message).css('color', 'red');
                        }
                    }
                });
            }
        });
        </script>
        <?php
    }

    /**
     * AJAX: Apply Points
     */
    public function ajax_apply_points() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array( 'message' => '請先登入' ) );
        
        $user_id = get_current_user_id();
        $amount = intval( $_POST['amount'] );
        $max_points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );

        if ( $amount < 0 ) $amount = 0;
        if ( $amount > $max_points ) {
            wp_send_json_error( array( 'message' => '積分不足' ) );
        }

        // Limit to Cart Total? Handled in apply_discounts logically, 
        // but user might input more than total. We accept it here and clamp later or let fees handle it (negative total impossible in WC usually).
        
        WC()->session->set( 'kayarine_points_applied', $amount );
        wp_send_json_success( array( 'message' => $amount > 0 ? "已套用 {$amount} 積分" : "已取消積分使用" ) );
    }

    /**
     * AJAX: Apply Wallet
     */
    public function ajax_apply_wallet() {
        if ( ! is_user_logged_in() ) wp_send_json_error( array( 'message' => '請先登入' ) );
        
        $user_id = get_current_user_id();
        $amount = floatval( $_POST['amount'] );
        $max_wallet = (float) get_user_meta( $user_id, Kayarine_Membership::META_WALLET, true );

        if ( $amount < 0 ) $amount = 0;
        if ( $amount > $max_wallet ) {
            wp_send_json_error( array( 'message' => '餘額不足' ) );
        }

        WC()->session->set( 'kayarine_wallet_applied', $amount );
        wp_send_json_success( array( 'message' => $amount > 0 ? "已套用 HK\${$amount} 儲值金" : "已取消儲值金使用" ) );
    }

    /**
     * Calculate Fees (Negative Fees = Discount)
     */
    public function apply_discounts( $cart ) {
        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;
        if ( ! is_user_logged_in() ) return;

        $points = WC()->session->get( 'kayarine_points_applied', 0 );
        $wallet = WC()->session->get( 'kayarine_wallet_applied', 0 );
        
        // Safety Check against user balance again
        $user_id = get_current_user_id();
        $max_points = (int) get_user_meta( $user_id, Kayarine_Membership::META_POINTS, true );
        $max_wallet = (float) get_user_meta( $user_id, Kayarine_Membership::META_WALLET, true );

        if ( $points > $max_points ) $points = $max_points;
        if ( $wallet > $max_wallet ) $wallet = $max_wallet;

        // Calculate Cart Total to prevent negative
        $cart_total = $cart->subtotal + $cart->shipping_total; // Before fees
        // Need to be careful with other fees.
        
        $discount_total = 0;

        if ( $points > 0 ) {
            // 1 Point = $1 Discount
            $discount = min( $points, $cart_total );
            $cart->add_fee( '會員積分折抵', -$discount );
            $cart_total -= $discount;
            $discount_total += $discount;
        }

        if ( $wallet > 0 && $cart_total > 0 ) {
            $discount = min( $wallet, $cart_total );
            $cart->add_fee( '儲值金付款', -$discount );
            $cart_total -= $discount;
            $discount_total += $discount;
        }
    }

    /**
     * Deduct Balance on Order Payment
     */
    public function deduct_loyalty_balance( $order_id ) {
        $order = wc_get_order( $order_id );
        if ( ! $order ) return;
        
        // Check if already deducted
        if ( $order->get_meta( '_kayarine_loyalty_deducted' ) ) return;

        $user_id = $order->get_user_id();
        
        // Parse Fees to find deductions
        $points_used = 0;
        $wallet_used = 0;

        foreach ( $order->get_fees() as $fee ) {
            if ( $fee->get_name() == '會員積分折抵' ) {
                $points_used += abs( $fee->get_total() ); // Fee is negative
            }
            if ( $fee->get_name() == '儲值金付款' ) {
                $wallet_used += abs( $fee->get_total() );
            }
        }

        $membership = new Kayarine_Membership();

        if ( $points_used > 0 ) {
            $membership->adjust_points( $user_id, -$points_used, 'redeem', $order_id, "訂單 #{$order_id} 折抵" );
        }

        if ( $wallet_used > 0 ) {
            $membership->adjust_wallet( $user_id, -$wallet_used, 'spend', $order_id, "訂單 #{$order_id} 付款" );
        }

        if ( $points_used > 0 || $wallet_used > 0 ) {
            $order->update_meta_data( '_kayarine_loyalty_deducted', 1 );
            $order->save();
        }
        
        // Clear session
        if ( isset( WC()->session ) ) {
            WC()->session->set( 'kayarine_points_applied', 0 );
            WC()->session->set( 'kayarine_wallet_applied', 0 );
        }
    }
}
