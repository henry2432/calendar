<?php
/**
 * Main Plugin Class
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Kayarine_Booking {

	public function run() {
		$this->load_dependencies();
		$this->define_admin_hooks();
		$this->define_public_hooks();
}

private function load_dependencies() {
		require_once KAYARINE_BOOKING_PATH . 'includes/kayarine-config.php';
		require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-pricing.php';
		// Inventory & Admin
		require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-inventory.php';
		require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-admin.php';

		   // New Product-Based Classes
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-booking-display.php';
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-cart-manager.php';
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-unified-booking.php'; // Unified Page
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-membership.php'; // Membership System
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-checkout-manager.php'; // Checkout Logic
		   require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-member-dashboard.php'; // Frontend Dashboard
		         
		         // Deprecated but kept if needed for backward compatibility during transition
		// require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-booking-shortcode.php';
		// require_once KAYARINE_BOOKING_PATH . 'includes/class-kayarine-booking-ajax.php';
	}

	private function define_admin_hooks() {
		// Initialize Admin Settings Page
		new Kayarine_Admin();
	}

	private function define_public_hooks() {
		// Initialize Product-Based Logic
		   new Kayarine_Booking_Display();
		   new Kayarine_Cart_Manager();
		   new Kayarine_Booking_Pricing();
		   new Kayarine_Unified_Booking(); // Unified Page
		   new Kayarine_Membership(); // Membership System
		   new Kayarine_Checkout_Manager(); // Checkout Logic
		   new Kayarine_Member_Dashboard(); // Frontend Dashboard

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		      // 5. Shipping Restrictions
		      add_filter( 'woocommerce_package_rates', array( $this, 'filter_shipping_methods' ), 10, 2 );
		      add_filter( 'woocommerce_cart_needs_shipping', array( $this, 'filter_needs_shipping' ) );

		            // 6. Cache Invalidation (Clear Inventory Cache on Order)
		            add_action( 'woocommerce_checkout_order_processed', array( $this, 'clear_inventory_cache' ), 10, 3 );
		            add_action( 'woocommerce_order_status_changed', array( $this, 'clear_inventory_cache_on_status_change' ), 10, 4 );
}

		  /**
		   * Clear Inventory Cache when a new order is placed
		   */
		  public function clear_inventory_cache( $order_id, $posted_data, $order ) {
		      $this->process_order_dates_for_clearing( $order );
		  }

		  /**
		   * Clear Inventory Cache when order status changes (e.g. Cancelled, Refunded)
		   * This ensures stock is freed up immediately in cache.
		   */
		  public function clear_inventory_cache_on_status_change( $order_id, $old_status, $new_status, $order ) {
		      $this->process_order_dates_for_clearing( $order );
		  }

		  /**
		   * Helper to find dates in order and clear cache
		   */
		  private function process_order_dates_for_clearing( $order ) {
		      if ( ! $order ) return;

		      $dates_to_clear = array();

		      foreach ( $order->get_items() as $item ) {
		          // Check item meta for date
		          // Meta key is usually 'kayarine_booking_date'
		          $date = $item->get_meta( 'kayarine_booking_date' );
		          if ( $date ) {
		              $dates_to_clear[$date] = true; // Use array key for unique
		          }
		      }

		      if ( ! empty( $dates_to_clear ) ) {
		          foreach ( array_keys( $dates_to_clear ) as $date ) {
		              Kayarine_Inventory::clear_cache( $date );
		          }
		      }
		  }

		  /**
		   * Disable Shipping for Specific Categories
		   * 1. 設備租借 (Equipment Rental)
		   * 2. 加購項目 (Add-ons)
		   * 3. 水上活動 (Water Activities)
		   */
		  public function filter_shipping_methods( $rates, $package ) {
		      // If cart has rental/service items, remove all shipping methods except maybe 'Local Pickup' if that's desired.
		      // Or if the request is to "Disable shipping options", it implies these products are Virtual/Service and don't need shipping.
		      
		      // However, if physical products are mixed, we might need complex logic.
		      // Assuming if ANY item is one of these categories, we disable standard shipping (require pickup or show no shipping needed).
		      
		      $restricted_categories = array( '設備租借', '加購項目', '水上活動' ); // Using slugs is better, but names provided
		      // Slugs likely: 'equipment-rental', 'add-ons', 'water-activities' - let's try to match by Term Name for safety or Slugs if we knew them.
		      // Based on CSV: '設備租借', '水上活動', '加購項目' are indeed Category names.
		      
		      $has_restricted_item = false;

		      foreach ( $package['contents'] as $item ) {
		          $product_id = $item['product_id'];
		          $terms = get_the_terms( $product_id, 'product_cat' );
		          
		          if ( $terms && ! is_wp_error( $terms ) ) {
		              foreach ( $terms as $term ) {
		                  if ( in_array( $term->name, $restricted_categories ) ) {
		                      $has_restricted_item = true;
		                      break 2;
		                  }
		              }
		          }
		      }

		      if ( $has_restricted_item ) {
		          // Remove all shipping rates
		          // If the user wants "Local Pickup" to remain, we would keep that.
		          // The prompt says "Disable shipping options", which usually means "No Shipping Required" or "Local Pickup Only".
		          // Since these are rentals/services, they are likely set as 'virtual' in WooCommerce?
		          // If they are not virtual, WC expects shipping.
		          // We will return empty array to disable shipping options if they are physical.
		          
		          // However, returning empty array might cause "No shipping method available" error.
		          // Often, for rentals, we just want "Local Pickup" (free) available, or we force them to be Virtual.
		          
		          // Let's assume we remove all PAID shipping. If Local Pickup exists, keep it.
		          foreach ( $rates as $rate_id => $rate ) {
		              if ( 'local_pickup' !== $rate->method_id ) {
		                  unset( $rates[ $rate_id ] );
		              }
		          }
		      }

		      return $rates;
		  }

		  /**
		   * Force "No Shipping Needed" if all items are in restricted categories?
		   * Or if they are physical but we just don't ship them.
		   */
		  public function filter_needs_shipping( $needs_shipping ) {
		      if ( ! $needs_shipping ) {
		          return false;
		      }

		      // If we want to force "No Shipping" (Virtual behavior) for these categories:
		      $restricted_categories = array( '設備租借', '加購項目', '水上活動' );
		      $all_restricted = true;
		      
		      // We need to check cart contents.
		      // Note: This filter runs often.
		      if ( WC()->cart->is_empty() ) {
		          return $needs_shipping;
		      }

		      foreach ( WC()->cart->get_cart() as $cart_item ) {
		          $product_id = $cart_item['product_id'];
		          $terms = get_the_terms( $product_id, 'product_cat' );
		          $item_is_restricted = false;
		          
		          if ( $terms && ! is_wp_error( $terms ) ) {
		              foreach ( $terms as $term ) {
		                  if ( in_array( $term->name, $restricted_categories ) ) {
		                      $item_is_restricted = true;
		                      break;
		                  }
		              }
		          }
		          
		          if ( ! $item_is_restricted ) {
		              $all_restricted = false;
		              break;
		          }
		      }

		      if ( $all_restricted ) {
		          return false; // Disable shipping entirely for these orders
		      }

		      return $needs_shipping;
		  }

public function enqueue_scripts() {
		   // Enqueue conditionally? Better done in Display class, but here is fine for now.
		   // We register them here, but enqueue in Display class.
		wp_register_style( 'kayarine-booking-css', KAYARINE_BOOKING_URL . 'assets/css/style.css', array(), KAYARINE_BOOKING_VERSION, 'all' );
		wp_register_script( 'kayarine-booking-js', KAYARINE_BOOKING_URL . 'assets/js/script.js', array( 'jquery' ), KAYARINE_BOOKING_VERSION, true );
		
		   // Pass Configuration & AJAX URL to JS
		$js_data = Kayarine_Config::get_js_config();
		
		wp_localize_script( 'kayarine-booking-js', 'kayarine_config', $js_data );
		wp_localize_script( 'kayarine-booking-js', 'kayarine_vars', array(
		    'ajax_url' => admin_url( 'admin-ajax.php' )
		));
}
}
